const BASE = import.meta.env.VITE_API_URL || "";

export const getToken = () => localStorage.getItem("vp_token");
export const setToken = (t) => (t ? localStorage.setItem("vp_token", t) : localStorage.removeItem("vp_token"));

async function request(path, { method = "GET", body, form } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (form) payload = form;
  else if (body !== undefined) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }
  const res = await fetch(`${BASE}/api${path}`, { method, headers, body: payload });
  if (res.status === 401 && token) {
    setToken(null);
    window.location.href = "/login";
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const detail = Array.isArray(data.detail) ? data.detail.map((d) => d.msg).join(", ") : data.detail;
    throw new Error(detail || `Request failed (${res.status})`);
  }
  return data;
}

export const api = {
  health: () => request("/health"),
  register: (b) => request("/auth/register", { method: "POST", body: b }),
  login: (b) => request("/auth/login", { method: "POST", body: b }),
  me: () => request("/auth/me"),
  profiles: () => request("/profiles"),
  addProfile: (b) => request("/profiles", { method: "POST", body: b }),
  updateProfile: (id, b) => request(`/profiles/${id}`, { method: "PUT", body: b }),
  deleteProfile: (id) => request(`/profiles/${id}`, { method: "DELETE" }),
  emergencyCard: (id) => request(`/profiles/${id}/emergency-card`),
  dashboard: (id) => request(`/profiles/${id}/dashboard`),
  timeline: (id) => request(`/profiles/${id}/timeline`),
  reports: (id) => request(`/profiles/${id}/reports`),
  report: (rid) => request(`/reports/${rid}`),
  uploadReport: (id, form) => request(`/profiles/${id}/reports`, { method: "POST", form }),
  explain: (rid, language) => request(`/reports/${rid}/explain`, { method: "POST", body: { language } }),
  deleteReport: (rid) => request(`/reports/${rid}`, { method: "DELETE" }),
  labs: (id, test = "") => request(`/profiles/${id}/labs?test=${encodeURIComponent(test)}`),
  labTests: (id) => request(`/profiles/${id}/labs/tests`),
  addLab: (id, b) => request(`/profiles/${id}/labs`, { method: "POST", body: b }),
  deleteLab: (lid) => request(`/labs/${lid}`, { method: "DELETE" }),
  medicines: (id) => request(`/profiles/${id}/medicines`),
  addMedicine: (id, b) => request(`/profiles/${id}/medicines`, { method: "POST", body: b }),
  updateMedicine: (mid, b) => request(`/medicines/${mid}`, { method: "PUT", body: b }),
  deleteMedicine: (mid) => request(`/medicines/${mid}`, { method: "DELETE" }),
  logDose: (mid, b) => request(`/medicines/${mid}/log`, { method: "POST", body: b }),
  today: (id) => request(`/profiles/${id}/reminders/today`),
  interactions: (id) => request(`/profiles/${id}/interactions`),
  chatHistory: (id) => request(`/profiles/${id}/chat`),
  chat: (id, b) => request(`/profiles/${id}/chat`, { method: "POST", body: b }),
  clearChat: (id) => request(`/profiles/${id}/chat`, { method: "DELETE" }),
  visitPrep: (id, b) => request(`/profiles/${id}/visit-prep`, { method: "POST", body: b }),
  exportData: () => request("/privacy/export"),
  deleteAccount: () => request("/privacy/account", { method: "DELETE" }),
};

const LABEL = { normal: "Normal", low: "Low", high: "High", critical_low: "Critical low", critical_high: "Critical high" };
export function StatusBadge({ status }) {
  return <span className={`badge b-${status}`}>{LABEL[status] || status}</span>;
}
export function Sev({ level }) {
  const cls = level === "high" ? "high-sev" : level === "low" ? "low-sev" : level;
  return <span className={`badge b-${cls}`}>{level}</span>;
}

import { useState } from "react";
import { NavLink } from "react-router-dom";
import { BookOpenCheck, ClipboardList, LayoutDashboard, LineChart, LogOut, Menu, MessageCircle, Pill, Settings, ShieldAlert } from "lucide-react";
import { useApp } from "../store.jsx";

const NAV = [
  ["/", "Dashboard", LayoutDashboard],
  ["/reports", "Reports", BookOpenCheck],
  ["/trends", "Lab Trends", LineChart],
  ["/medicines", "Medicines", Pill],
  ["/copilot", "AI Copilot", MessageCircle],
  ["/visit-prep", "Doctor Visit Prep", ClipboardList],
  ["/emergency-card", "Emergency Card", ShieldAlert],
  ["/settings", "Profiles & Privacy", Settings],
];

export function Logo() {
  return (
    <div className="logo">
      <svg viewBox="0 0 64 64"><rect width="64" height="64" rx="16" fill="#14b8a6" /><path d="M8 34h13l5-12 8 24 6-16h16" fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" /></svg>
      VitaPilot
    </div>
  );
}

export default function Layout({ children }) {
  const { profiles, profileId, setProfileId, user, signOut } = useApp();
  const [open, setOpen] = useState(false);
  return (
    <div className="app">
      <aside className={`side ${open ? "open" : ""}`}>
        <Logo />
        <div style={{ padding: "0 4px 12px" }}>
          <label style={{ color: "#8fa3ad" }}>Viewing health record of</label>
          <select value={profileId || ""} onChange={(e) => setProfileId(Number(e.target.value))}>
            {profiles.map((p) => <option key={p.id} value={p.id}>{p.name} ({p.relation})</option>)}
          </select>
        </div>
        <nav className="nav" onClick={() => setOpen(false)}>
          {NAV.map(([to, label, Icon]) => (
            <NavLink key={to} to={to} end={to === "/"} className={({ isActive }) => (isActive ? "active" : "")}>
              <Icon size={18} /> {label}
            </NavLink>
          ))}
        </nav>
        <div className="spacer" />
        <div className="muted" style={{ color: "#8fa3ad", padding: "0 10px" }}>{user?.email}</div>
        <button className="btn ghost" style={{ color: "#cbd5e1", borderColor: "#27404d", justifyContent: "center" }} onClick={signOut}>
          <LogOut size={16} /> Sign out
        </button>
      </aside>
      <main className="main">
        <button className="btn ghost menu-btn no-print" style={{ marginBottom: 12 }} onClick={() => setOpen(!open)}><Menu size={18} /> Menu</button>
        {children}
        <p className="disclaimer no-print">VitaPilot provides general health information, not medical advice. In an emergency call 112 (India) or 108 for an ambulance.</p>
      </main>
    </div>
  );
}

export function PageHead({ title, sub, children }) {
  return (
    <div className="topbar">
      <div><h1>{title}</h1>{sub && <div className="sub">{sub}</div>}</div>
      <div className="row no-print">{children}</div>
    </div>
  );
}

export const LANGS = [["en", "English"], ["hi", "Hindi"], ["te", "Telugu"], ["ta", "Tamil"], ["bn", "Bengali"], ["mr", "Marathi"], ["kn", "Kannada"], ["ml", "Malayalam"], ["gu", "Gujarati"]];

// Small, dependency-free and XSS-safe markdown renderer (headings, lists, bold, italic).
function inline(text, key) {
  const parts = text.split(/(\*\*[^*]+\*\*|_[^_]+_|\*[^*]+\*)/g).filter(Boolean);
  return parts.map((p, i) => {
    if (p.startsWith("**") && p.endsWith("**")) return <strong key={`${key}-${i}`}>{p.slice(2, -2)}</strong>;
    if ((p.startsWith("_") && p.endsWith("_")) || (p.startsWith("*") && p.endsWith("*"))) return <em key={`${key}-${i}`}>{p.slice(1, -1)}</em>;
    return p;
  });
}

export default function Markdown({ text = "" }) {
  const lines = text.split("\n");
  const out = [];
  let list = null;
  const flush = () => {
    if (list) {
      const Tag = list.ordered ? "ol" : "ul";
      out.push(<Tag key={`l${out.length}`}>{list.items}</Tag>);
      list = null;
    }
  };
  lines.forEach((raw, i) => {
    const line = raw.trimEnd();
    const h = line.match(/^(#{1,3})\s+(.*)/);
    const li = line.match(/^\s*(?:[-*]|(\d+)\.)\s+(.*)/);
    if (h) { flush(); const Tag = `h${h[1].length}`; out.push(<Tag key={i}>{inline(h[2], i)}</Tag>); }
    else if (li) {
      const ordered = !!li[1];
      if (!list || list.ordered !== ordered) { flush(); list = { ordered, items: [] }; }
      list.items.push(<li key={i}>{inline(li[2], i)}</li>);
    } else if (!line.trim()) flush();
    else { flush(); out.push(<p key={i}>{inline(line, i)}</p>); }
  });
  flush();
  return <div className="md">{out}</div>;
}

import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api, getToken, setToken } from "./api.js";

const Ctx = createContext(null);
export const useApp = () => useContext(Ctx);

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profiles, setProfiles] = useState([]);
  const [profileId, setProfileId] = useState(() => Number(localStorage.getItem("vp_profile")) || null);
  const [booting, setBooting] = useState(!!getToken());

  const loadProfiles = useCallback(async () => {
    const list = await api.profiles();
    setProfiles(list);
    setProfileId((cur) => (list.find((p) => p.id === cur) ? cur : list[0]?.id ?? null));
    return list;
  }, []);

  useEffect(() => {
    if (!getToken()) return;
    api.me().then(setUser).then(loadProfiles).catch(() => setToken(null)).finally(() => setBooting(false));
  }, [loadProfiles]);

  useEffect(() => {
    if (profileId) localStorage.setItem("vp_profile", String(profileId));
  }, [profileId]);

  const signIn = async (res) => {
    setToken(res.token);
    setUser(res.user);
    await loadProfiles();
  };
  const signOut = () => {
    setToken(null);
    setUser(null);
    setProfiles([]);
    window.location.href = "/login";
  };

  const profile = profiles.find((p) => p.id === profileId) || null;
  return (
    <Ctx.Provider value={{ user, profiles, profile, profileId, setProfileId, loadProfiles, signIn, signOut, booting }}>
      {children}
    </Ctx.Provider>
  );
}

import { Navigate, Route, Routes } from "react-router-dom";
import { useApp } from "./store.jsx";
import Layout from "./components/Layout.jsx";
import Auth from "./pages/Auth.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Reports from "./pages/Reports.jsx";
import Trends from "./pages/Trends.jsx";
import Medicines from "./pages/Medicines.jsx";
import Copilot from "./pages/Copilot.jsx";
import VisitPrep from "./pages/VisitPrep.jsx";
import EmergencyCard from "./pages/EmergencyCard.jsx";
import Settings from "./pages/Settings.jsx";

function Protected({ children }) {
  const { user, booting } = useApp();
  if (booting) return <div className="splash">Loading VitaPilot...</div>;
  if (!user) return <Navigate to="/login" replace />;
  return <Layout>{children}</Layout>;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Auth mode="login" />} />
      <Route path="/register" element={<Auth mode="register" />} />
      <Route path="/" element={<Protected><Dashboard /></Protected>} />
      <Route path="/reports" element={<Protected><Reports /></Protected>} />
      <Route path="/trends" element={<Protected><Trends /></Protected>} />
      <Route path="/medicines" element={<Protected><Medicines /></Protected>} />
      <Route path="/copilot" element={<Protected><Copilot /></Protected>} />
      <Route path="/visit-prep" element={<Protected><VisitPrep /></Protected>} />
      <Route path="/emergency-card" element={<Protected><EmergencyCard /></Protected>} />
      <Route path="/settings" element={<Protected><Settings /></Protected>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { AlertTriangle, CheckCircle2, FileText, Pill, TrendingDown, TrendingUp } from "lucide-react";
import { api } from "../api.js";
import { useApp } from "../store.jsx";
import { PageHead } from "../components/Layout.jsx";
import { Sev, StatusBadge } from "../components/Badge.jsx";

function ScoreRing({ score }) {
  const r = 62, c = 2 * Math.PI * r;
  const pct = score ?? 0;
  const color = pct >= 80 ? "#16a34a" : pct >= 55 ? "#d97706" : "#dc2626";
  return (
    <div className="ring">
      <svg viewBox="0 0 150 150" width="150" height="150">
        <circle cx="75" cy="75" r={r} fill="none" stroke="var(--line)" strokeWidth="12" />
        <circle cx="75" cy="75" r={r} fill="none" stroke={color} strokeWidth="12" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - pct / 100)} transform="rotate(-90 75 75)" style={{ transition: "stroke-dashoffset .8s" }} />
      </svg>
      <span>{score ?? "--"}</span>
    </div>
  );
}

export default function Dashboard() {
  const { profile, profileId } = useApp();
  const [d, setD] = useState(null);
  const [doses, setDoses] = useState([]);
  const [inter, setInter] = useState([]);
  const [tl, setTl] = useState([]);
  const [err, setErr] = useState("");

  const load = useCallback(() => {
    if (!profileId) return;
    Promise.all([api.dashboard(profileId), api.today(profileId), api.interactions(profileId), api.timeline(profileId)])
      .then(([a, b, c, t]) => { setD(a); setDoses(b); setInter(c); setTl(t); })
      .catch((e) => setErr(e.message));
  }, [profileId]);
  useEffect(load, [load]);

  const take = async (dose) => { await api.logDose(dose.medicine_id, { time: dose.time, taken: !dose.taken }); load(); };

  if (err) return <div className="alert err">{err}</div>;
  if (!d) return <div className="muted">Loading your dashboard...</div>;
  const empty = d.tests_tracked === 0;

  return (
    <>
      <PageHead title={`Hello, ${profile?.name?.split(" ")[0] || "there"}`} sub="Here is where your health stands today">
        <span className={`badge ${d.ai_mode === "claude" ? "b-normal" : "b-info"}`}>AI: {d.ai_mode === "claude" ? "VitaMind (Claude)" : "Demo mode"}</span>
        <Link to="/reports" className="btn"><FileText size={16} /> Upload report</Link>
      </PageHead>

      {empty && <div className="alert warn" style={{ marginBottom: 16 }}>No results yet. <Link to="/reports">Upload a lab report</Link> (or use the sample report) to unlock your Vita Score, trends and insights.</div>}

      <div className="grid g3" style={{ marginBottom: 16 }}>
        <div className="card" style={{ textAlign: "center" }}>
          <ScoreRing score={d.vita_score} />
          <h3 style={{ marginTop: 10 }}>Vita Score</h3>
          <div className="muted">Share of your latest results that are in range</div>
        </div>
        <div className="card">
          <h3>Snapshot</h3>
          <div className="grid g2" style={{ marginTop: 12 }}>
            <div><div className="stat">{d.tests_tracked}</div><div className="muted">Tests tracked</div></div>
            <div><div className="stat">{d.counts.reports}</div><div className="muted">Reports</div></div>
            <div><div className="stat">{d.counts.medicines}</div><div className="muted">Active medicines</div></div>
            <div><div className="stat">{d.adherence_7d ?? "--"}{d.adherence_7d != null && "%"}</div><div className="muted">7-day adherence</div></div>
          </div>
        </div>
        <div className="card">
          <div className="row between"><h3>Today's doses</h3><Link to="/medicines" className="muted">Manage</Link></div>
          <div className="list" style={{ marginTop: 10 }}>
            {doses.length === 0 && <div className="muted">No reminders scheduled.</div>}
            {doses.map((x) => (
              <div className="item" key={`${x.medicine_id}-${x.time}`}>
                <div><strong>{x.name}</strong> <span className="muted">{x.dose}</span><div className="muted">{x.time}</div></div>
                <button className={`btn sm ${x.taken ? "" : "ghost"}`} onClick={() => take(x)}>{x.taken ? <><CheckCircle2 size={14} /> Taken</> : "Mark taken"}</button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {(d.patterns.length > 0 || inter.length > 0) && (
        <div className="card" style={{ marginBottom: 16 }}>
          <h2 style={{ marginBottom: 10 }}><AlertTriangle size={18} style={{ verticalAlign: "-3px" }} /> Smart insights</h2>
          <div className="list">
            {d.patterns.map((p) => (
              <div className="item" key={p.title}><div><strong>{p.title}</strong><div className="muted">{p.detail}</div></div><Sev level={p.level} /></div>
            ))}
            {inter.map((i) => (
              <div className="item" key={i.drugs.join()}><div><strong><Pill size={14} /> {i.drugs.join(" + ")}</strong><div className="muted">{i.note}</div></div><Sev level={i.severity} /></div>
            ))}
          </div>
        </div>
      )}

      <div className="grid g2">
        <div className="card">
          <h2 style={{ marginBottom: 10 }}>Needs attention</h2>
          {d.flagged.length === 0 ? <div className="muted">Nothing out of range in your latest results.</div> : (
            <table><thead><tr><th>Test</th><th>Value</th><th>Status</th></tr></thead><tbody>
              {d.flagged.map((f) => (
                <tr key={f.test_name}>
                  <td>{f.test_name}</td>
                  <td>{f.value} {f.unit} {f.trend === "up" && <TrendingUp size={14} color="#dc2626" />}{f.trend === "down" && <TrendingDown size={14} color="#2563eb" />}</td>
                  <td><StatusBadge status={f.status} /></td>
                </tr>
              ))}
            </tbody></table>
          )}
        </div>
        <div className="card">
          <h2 style={{ marginBottom: 10 }}>Health timeline</h2>
          <div className="list">
            {tl.length === 0 && <div className="muted">Your timeline will appear here.</div>}
            {tl.slice(0, 8).map((e, i) => (
              <div className="item" key={i}><div><strong>{e.title}</strong><div className="muted">{e.detail}</div></div><span className="muted">{e.date}</span></div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

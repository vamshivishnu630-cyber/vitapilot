import { useEffect, useRef, useState } from "react";
import { Send, Siren, Trash2 } from "lucide-react";
import { api } from "../api.js";
import { useApp } from "../store.jsx";
import { LANGS, PageHead } from "../components/Layout.jsx";
import Markdown from "../components/Markdown.jsx";

const SUGGEST = ["Explain my latest results in simple words", "Which of my results need attention?", "What does a high HbA1c mean?", "What should I ask my doctor?", "Are my medicines safe to take together?"];

export default function Copilot() {
  const { profile, profileId } = useApp();
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState("");
  const [lang, setLang] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef(null);

  useEffect(() => { if (profileId) api.chatHistory(profileId).then(setMsgs); }, [profileId]);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs, busy]);

  const send = async (q) => {
    const message = (q ?? text).trim();
    if (!message || busy) return;
    setText(""); setMsgs((m) => [...m, { role: "user", content: message }]); setBusy(true);
    try {
      const r = await api.chat(profileId, { message, language: lang || profile?.language });
      setMsgs((m) => [...m, { role: "assistant", content: r.answer, sources: r.sources, flag: r.flag }]);
    } catch (e) { setMsgs((m) => [...m, { role: "assistant", content: `Sorry, something went wrong: ${e.message}` }]); }
    finally { setBusy(false); }
  };
  const clear = async () => { if (confirm("Clear this conversation?")) { await api.clearChat(profileId); setMsgs([]); } };

  return (
    <>
      <PageHead title="VitaMind Copilot" sub="Answers are grounded in your own records and a curated health knowledge base">
        <select style={{ width: 150 }} value={lang || profile?.language || "en"} onChange={(e) => setLang(e.target.value)}>
          {LANGS.map(([c, n]) => <option key={c} value={c}>{n}</option>)}
        </select>
        <button className="btn ghost" onClick={clear}><Trash2 size={15} /> Clear</button>
      </PageHead>
      <div className="card chat">
        <div className="msgs">
          {msgs.length === 0 && (
            <div>
              <p className="muted">Hi {profile?.name?.split(" ")[0]}, I can explain your reports, spot patterns and help you prepare for the doctor. Try:</p>
              <div className="row" style={{ marginTop: 8 }}>{SUGGEST.map((s) => <button key={s} className="chip" onClick={() => send(s)}>{s}</button>)}</div>
            </div>
          )}
          {msgs.map((m, i) => (
            <div key={i} className={`bubble ${m.role === "user" ? "user" : "bot"} ${m.flag ? "flag" : ""}`}>
              {m.flag && <div className="row" style={{ marginBottom: 6 }}><Siren size={16} /> <strong>Safety alert</strong></div>}
              {m.role === "user" ? m.content : <Markdown text={m.content} />}
              {m.sources?.length > 0 && <div className="src">Sources: {m.sources.join(" | ")}</div>}
            </div>
          ))}
          {busy && <div className="bubble bot muted">VitaMind is thinking...</div>}
          <div ref={end} />
        </div>
        <form className="composer" onSubmit={(e) => { e.preventDefault(); send(); }}>
          <input placeholder="Ask about your reports, medicines or health..." value={text} onChange={(e) => setText(e.target.value)} maxLength={2000} />
          <button className="btn" disabled={busy}><Send size={16} /> Send</button>
        </form>
      </div>
    </>
  );
}

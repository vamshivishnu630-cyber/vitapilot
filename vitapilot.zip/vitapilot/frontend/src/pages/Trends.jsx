import { useEffect, useState } from "react";
import { CartesianGrid, Line, LineChart, ReferenceArea, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Trash2 } from "lucide-react";
import { api } from "../api.js";
import { useApp } from "../store.jsx";
import { PageHead } from "../components/Layout.jsx";
import { StatusBadge } from "../components/Badge.jsx";

export default function Trends() {
  const { profileId } = useApp();
  const [tests, setTests] = useState([]);
  const [test, setTest] = useState("");
  const [rows, setRows] = useState([]);
  const [f, setF] = useState({ test_name: "", value: "", unit: "", taken_on: "" });
  const [err, setErr] = useState("");

  const loadTests = () => api.labTests(profileId).then((t) => { setTests(t); setTest((cur) => (t.includes(cur) ? cur : t[0] || "")); });
  useEffect(() => { if (profileId) loadTests(); }, [profileId]);
  useEffect(() => { if (profileId && test) api.labs(profileId, test).then(setRows); else setRows([]); }, [profileId, test]);

  const add = async (e) => {
    e.preventDefault(); setErr("");
    try {
      await api.addLab(profileId, { test_name: f.test_name, value: Number(f.value), unit: f.unit, taken_on: f.taken_on || null });
      setF({ test_name: "", value: "", unit: "", taken_on: "" }); await loadTests();
      if (test) api.labs(profileId, test).then(setRows);
    } catch (ex) { setErr(ex.message); }
  };
  const remove = async (id) => { await api.deleteLab(id); loadTests(); api.labs(profileId, test).then(setRows); };

  const low = rows[0]?.ref_low, high = rows[0]?.ref_high;
  const vals = rows.map((r) => r.value);
  const min = Math.min(...vals, low ?? Infinity), max = Math.max(...vals, high ?? -Infinity);
  const pad = (max - min) * 0.2 || 1;

  return (
    <>
      <PageHead title="Lab trends" sub="Watch how each result moves over time against its reference range">
        <select style={{ width: 240 }} value={test} onChange={(e) => setTest(e.target.value)}>
          {tests.length === 0 && <option>No tests yet</option>}
          {tests.map((t) => <option key={t}>{t}</option>)}
        </select>
      </PageHead>

      <div className="card" style={{ marginBottom: 16 }}>
        {rows.length === 0 ? <div className="muted">Upload reports or add a manual result below to see a chart.</div> : (
          <div style={{ height: 320 }}>
            <ResponsiveContainer>
              <LineChart data={rows} margin={{ top: 10, right: 20, bottom: 0, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" />
                <XAxis dataKey="taken_on" stroke="var(--muted)" fontSize={12} />
                <YAxis domain={[Math.floor(min - pad), Math.ceil(max + pad)]} stroke="var(--muted)" fontSize={12} />
                <Tooltip />
                {low != null && high != null && <ReferenceArea y1={low} y2={high} fill="#16a34a" fillOpacity={0.12} label={{ value: "Healthy range", fontSize: 11, fill: "#16a34a" }} />}
                <Line type="monotone" dataKey="value" stroke="#0f766e" strokeWidth={3} dot={{ r: 5 }} name={rows[0]?.unit || "value"} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>

      <div className="grid g2" style={{ alignItems: "start" }}>
        <div className="card">
          <h2 style={{ marginBottom: 10 }}>History</h2>
          <table><thead><tr><th>Date</th><th>Value</th><th>Status</th><th /></tr></thead><tbody>
            {rows.map((r) => (
              <tr key={r.id}><td>{r.taken_on}</td><td>{r.value} {r.unit}</td><td><StatusBadge status={r.status} /></td>
                <td><button className="btn ghost sm" onClick={() => remove(r.id)}><Trash2 size={13} /></button></td></tr>
            ))}
          </tbody></table>
        </div>
        <form className="card" onSubmit={add}>
          <h2 style={{ marginBottom: 10 }}>Add a result manually</h2>
          <div className="field"><label>Test name</label><input required list="tests" placeholder="e.g. HbA1c" value={f.test_name} onChange={(e) => setF({ ...f, test_name: e.target.value })} />
            <datalist id="tests">{["Hemoglobin", "HbA1c", "Fasting Glucose", "Total Cholesterol", "LDL Cholesterol", "HDL Cholesterol", "Triglycerides", "TSH", "Vitamin D", "Vitamin B12", "Creatinine"].map((t) => <option key={t} value={t} />)}</datalist></div>
          <div className="grid g2">
            <div className="field"><label>Value</label><input required type="number" step="any" value={f.value} onChange={(e) => setF({ ...f, value: e.target.value })} /></div>
            <div className="field"><label>Date</label><input type="date" value={f.taken_on} onChange={(e) => setF({ ...f, taken_on: e.target.value })} /></div>
          </div>
          <div className="field"><label>Unit (optional)</label><input value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })} /></div>
          {err && <div className="alert err" style={{ marginBottom: 10 }}>{err}</div>}
          <button className="btn">Add result</button>
        </form>
      </div>
    </>
  );
}

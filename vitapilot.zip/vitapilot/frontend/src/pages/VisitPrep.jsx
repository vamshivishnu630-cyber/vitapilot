import { useState } from "react";
import { Printer, Sparkles } from "lucide-react";
import { api } from "../api.js";
import { useApp } from "../store.jsx";
import { LANGS, PageHead } from "../components/Layout.jsx";
import Markdown from "../components/Markdown.jsx";

export default function VisitPrep() {
  const { profile, profileId } = useApp();
  const [reason, setReason] = useState("");
  const [lang, setLang] = useState("");
  const [brief, setBrief] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const go = async () => {
    setBusy(true); setErr("");
    try { setBrief((await api.visitPrep(profileId, { reason, language: lang || profile?.language })).brief); }
    catch (e) { setErr(e.message); } finally { setBusy(false); }
  };

  return (
    <>
      <PageHead title="Doctor visit prep" sub="A one-page brief of your results, medicines and the right questions to ask" />
      <div className="card no-print" style={{ marginBottom: 16 }}>
        <div className="grid g3" style={{ alignItems: "end" }}>
          <div><label>Reason for visit</label><input placeholder="e.g. Follow-up on high sugar" value={reason} onChange={(e) => setReason(e.target.value)} /></div>
          <div><label>Language</label>
            <select value={lang || profile?.language || "en"} onChange={(e) => setLang(e.target.value)}>{LANGS.map(([c, n]) => <option key={c} value={c}>{n}</option>)}</select></div>
          <div className="row"><button className="btn" onClick={go} disabled={busy}><Sparkles size={16} /> {busy ? "Preparing..." : "Generate brief"}</button>
            {brief && <button className="btn ghost" onClick={() => window.print()}><Printer size={16} /> Print / Save PDF</button>}</div>
        </div>
        {err && <div className="alert err" style={{ marginTop: 10 }}>{err}</div>}
      </div>
      {brief && <div className="card"><Markdown text={brief} /></div>}
    </>
  );
}

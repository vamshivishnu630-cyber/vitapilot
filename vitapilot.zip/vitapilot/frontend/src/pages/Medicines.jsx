import { useEffect, useState } from "react";
import { Pill, Trash2 } from "lucide-react";
import { api } from "../api.js";
import { useApp } from "../store.jsx";
import { PageHead } from "../components/Layout.jsx";
import { Sev } from "../components/Badge.jsx";

const blank = { name: "", dose: "", times: "08:00", notes: "" };

export default function Medicines() {
  const { profileId } = useApp();
  const [meds, setMeds] = useState([]);
  const [inter, setInter] = useState([]);
  const [f, setF] = useState(blank);
  const [err, setErr] = useState("");

  const load = () => Promise.all([api.medicines(profileId), api.interactions(profileId)]).then(([m, i]) => { setMeds(m); setInter(i); });
  useEffect(() => { if (profileId) load(); }, [profileId]);

  const add = async (e) => {
    e.preventDefault(); setErr("");
    try { await api.addMedicine(profileId, f); setF(blank); load(); } catch (ex) { setErr(ex.message); }
  };
  const toggle = async (m) => { await api.updateMedicine(m.id, { ...m, active: !m.active }); load(); };
  const remove = async (m) => { if (confirm(`Remove ${m.name}?`)) { await api.deleteMedicine(m.id); load(); } };

  return (
    <>
      <PageHead title="Medicines" sub="Keep one accurate list. VitaPilot checks active medicines for known interactions." />
      {inter.length > 0 && (
        <div className="card" style={{ marginBottom: 16, borderColor: "#fca5a5" }}>
          <h2 style={{ marginBottom: 8 }}>Interaction warnings</h2>
          <div className="list">{inter.map((i) => (
            <div className="item" key={i.drugs.join()}><div><strong>{i.drugs.join(" + ")}</strong><div className="muted">{i.note}</div></div><Sev level={i.severity} /></div>
          ))}</div>
          <p className="muted" style={{ marginTop: 8 }}>Do not stop any medicine on your own. Ask your doctor or pharmacist.</p>
        </div>
      )}
      <div className="grid g2" style={{ alignItems: "start" }}>
        <div className="card">
          <h2 style={{ marginBottom: 10 }}>Your medicines</h2>
          <div className="list">
            {meds.length === 0 && <div className="muted">No medicines added.</div>}
            {meds.map((m) => (
              <div className="item" key={m.id} style={{ opacity: m.active ? 1 : 0.55 }}>
                <div><strong><Pill size={14} /> {m.name}</strong> <span className="muted">{m.dose}</span><div className="muted">At {m.times}{m.notes && ` - ${m.notes}`}</div></div>
                <div className="row">
                  <button className="btn ghost sm" onClick={() => toggle(m)}>{m.active ? "Pause" : "Resume"}</button>
                  <button className="btn ghost sm" onClick={() => remove(m)}><Trash2 size={13} /></button>
                </div>
              </div>
            ))}
          </div>
        </div>
        <form className="card" onSubmit={add}>
          <h2 style={{ marginBottom: 10 }}>Add medicine</h2>
          <div className="field"><label>Name</label><input required placeholder="e.g. Metformin" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
          <div className="grid g2">
            <div className="field"><label>Dose</label><input placeholder="500 mg" value={f.dose} onChange={(e) => setF({ ...f, dose: e.target.value })} /></div>
            <div className="field"><label>Times (24h, comma separated)</label><input placeholder="08:00,20:00" value={f.times} onChange={(e) => setF({ ...f, times: e.target.value })} /></div>
          </div>
          <div className="field"><label>Notes</label><input placeholder="After food" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></div>
          {err && <div className="alert err" style={{ marginBottom: 10 }}>{err}</div>}
          <button className="btn">Add medicine</button>
        </form>
      </div>
    </>
  );
}

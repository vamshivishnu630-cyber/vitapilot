import { useEffect, useState } from "react";
import { Printer } from "lucide-react";
import { api } from "../api.js";
import { useApp } from "../store.jsx";
import { PageHead } from "../components/Layout.jsx";

export default function EmergencyCard() {
  const { profileId } = useApp();
  const [c, setC] = useState(null);
  useEffect(() => { if (profileId) api.emergencyCard(profileId).then(setC); }, [profileId]);
  if (!c) return null;
  const Row = ({ k, v }) => <tr><th style={{ width: 150 }}>{k}</th><td>{v || <span className="muted">Not set</span>}</td></tr>;
  return (
    <>
      <PageHead title="Emergency card" sub="Print it, keep it in your wallet or save a screenshot on your phone lock screen">
        <button className="btn" onClick={() => window.print()}><Printer size={16} /> Print</button>
      </PageHead>
      <div className="card ecard">
        <h2>EMERGENCY MEDICAL INFORMATION</h2>
        <h1 style={{ margin: "6px 0 12px" }}>{c.name}</h1>
        <table><tbody>
          <Row k="Blood group" v={c.blood_group} />
          <Row k="Date of birth" v={c.dob} />
          <Row k="Allergies" v={c.allergies} />
          <Row k="Conditions" v={c.conditions} />
          <Row k="Current medicines" v={c.medicines.join(", ")} />
          <Row k="Emergency contact" v={c.emergency_contact} />
        </tbody></table>
        <p className="muted" style={{ marginTop: 10 }}>Emergency numbers (India): 112 national, 108 ambulance.</p>
      </div>
      <p className="muted no-print" style={{ marginTop: 10 }}>Edit these details in Profiles &amp; Privacy.</p>
    </>
  );
}

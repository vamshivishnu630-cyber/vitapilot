import { useState } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { api } from "../api.js";
import { useApp } from "../store.jsx";
import { Logo } from "../components/Layout.jsx";

export default function Auth({ mode }) {
  const isReg = mode === "register";
  const { user, signIn } = useApp();
  const nav = useNavigate();
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/" replace />;

  const submit = async (e) => {
    e.preventDefault();
    setErr(""); setBusy(true);
    try {
      const res = isReg ? await api.register(f) : await api.login({ email: f.email, password: f.password });
      await signIn(res);
      nav("/");
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  return (
    <div className="auth">
      <section className="auth-hero">
        <Logo />
        <h1>Your health, finally in one place and in plain language.</h1>
        <ul>
          <li>Upload any lab report and understand it in seconds</li>
          <li>Track trends, medicines and doctor visits for the whole family</li>
          <li>Ask the VitaMind copilot questions grounded in your own records</li>
          <li>Private by design: export or delete your data anytime</li>
        </ul>
      </section>
      <section className="auth-form">
        <form className="card" onSubmit={submit}>
          <h2 style={{ marginBottom: 14 }}>{isReg ? "Create your account" : "Welcome back"}</h2>
          {isReg && <div className="field"><label>Full name</label><input required value={f.name} onChange={set("name")} /></div>}
          <div className="field"><label>Email</label><input type="email" required value={f.email} onChange={set("email")} /></div>
          <div className="field"><label>Password {isReg && "(min 8 characters)"}</label><input type="password" required minLength={isReg ? 8 : 1} value={f.password} onChange={set("password")} /></div>
          {err && <div className="alert err" style={{ marginBottom: 12 }}>{err}</div>}
          <button className="btn" style={{ width: "100%", justifyContent: "center" }} disabled={busy}>{busy ? "Please wait..." : isReg ? "Sign up" : "Sign in"}</button>
          <p className="muted" style={{ textAlign: "center", marginTop: 14 }}>
            {isReg ? <>Already registered? <Link to="/login">Sign in</Link></> : <>New here? <Link to="/register">Create an account</Link></>}
          </p>
        </form>
      </section>
    </div>
  );
}

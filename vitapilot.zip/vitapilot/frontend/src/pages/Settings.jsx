import { useEffect, useState } from "react";
import { Download, Plus, Trash2 } from "lucide-react";
import { api } from "../api.js";
import { useApp } from "../store.jsx";
import { LANGS, PageHead } from "../components/Layout.jsx";

const blank = { name: "", relation: "Family", dob: "", sex: "", language: "en", blood_group: "", allergies: "", conditions: "", emergency_contact: "" };

export default function Settings() {
  const { profiles, profile, profileId, setProfileId, loadProfiles, signOut } = useApp();
  const [f, setF] = useState(blank);
  const [isNew, setIsNew] = useState(false);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => { if (profile && !isNew) setF({ ...blank, ...profile, dob: profile.dob || "" }); }, [profile, isNew]);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const save = async (e) => {
    e.preventDefault(); setErr(""); setMsg("");
    const body = { ...f, dob: f.dob || null };
    try {
      if (isNew) { const p = await api.addProfile(body); await loadProfiles(); setProfileId(p.id); setIsNew(false); }
      else { await api.updateProfile(profileId, body); await loadProfiles(); }
      setMsg("Saved.");
    } catch (ex) { setErr(ex.message); }
  };
  const remove = async () => {
    if (!confirm(`Delete ${profile.name} and all their records?`)) return;
    try { await api.deleteProfile(profileId); await loadProfiles(); } catch (ex) { setErr(ex.message); }
  };
  const exportData = async () => {
    const data = await api.exportData();
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));
    const a = document.createElement("a"); a.href = url; a.download = "vitapilot-export.json"; a.click(); URL.revokeObjectURL(url);
  };
  const wipe = async () => {
    if (prompt("This permanently deletes your account and ALL health data. Type DELETE to confirm.") === "DELETE") {
      await api.deleteAccount(); signOut();
    }
  };

  return (
    <>
      <PageHead title="Profiles & privacy" sub="Manage family members and control your data">
        <button className="btn" onClick={() => { setIsNew(true); setF(blank); setMsg(""); }}><Plus size={16} /> Add family member</button>
      </PageHead>
      <div className="grid g2" style={{ alignItems: "start" }}>
        <form className="card" onSubmit={save}>
          <h2 style={{ marginBottom: 12 }}>{isNew ? "New profile" : "Edit profile"}</h2>
          {!isNew && profiles.length > 1 && (
            <div className="field"><label>Profile</label><select value={profileId} onChange={(e) => setProfileId(Number(e.target.value))}>{profiles.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
          )}
          <div className="grid g2">
            <div className="field"><label>Name</label><input required value={f.name} onChange={set("name")} /></div>
            <div className="field"><label>Relation</label><input value={f.relation} onChange={set("relation")} /></div>
            <div className="field"><label>Date of birth</label><input type="date" value={f.dob} onChange={set("dob")} /></div>
            <div className="field"><label>Sex</label><select value={f.sex} onChange={set("sex")}><option value="">--</option><option>Female</option><option>Male</option><option>Other</option></select></div>
            <div className="field"><label>Blood group</label><input placeholder="O+" value={f.blood_group} onChange={set("blood_group")} /></div>
            <div className="field"><label>Preferred language</label><select value={f.language} onChange={set("language")}>{LANGS.map(([c, n]) => <option key={c} value={c}>{n}</option>)}</select></div>
          </div>
          <div className="field"><label>Allergies</label><input value={f.allergies} onChange={set("allergies")} /></div>
          <div className="field"><label>Known conditions</label><input value={f.conditions} onChange={set("conditions")} /></div>
          <div className="field"><label>Emergency contact (name and phone)</label><input value={f.emergency_contact} onChange={set("emergency_contact")} /></div>
          {err && <div className="alert err" style={{ marginBottom: 10 }}>{err}</div>}
          {msg && <div className="alert ok" style={{ marginBottom: 10 }}>{msg}</div>}
          <div className="row">
            <button className="btn">{isNew ? "Create profile" : "Save changes"}</button>
            {isNew && <button type="button" className="btn ghost" onClick={() => setIsNew(false)}>Cancel</button>}
            {!isNew && profiles.length > 1 && <button type="button" className="btn ghost" onClick={remove}><Trash2 size={15} /> Delete profile</button>}
          </div>
        </form>

        <div className="card">
          <h2 style={{ marginBottom: 10 }}>Your data, your control</h2>
          <p className="muted">Health data is sensitive. VitaPilot stores it only to serve you. You can download everything or erase it permanently at any time.</p>
          <div className="row" style={{ marginTop: 14 }}>
            <button className="btn ghost" onClick={exportData}><Download size={16} /> Export all my data</button>
            <button className="btn danger" onClick={wipe}><Trash2 size={16} /> Delete my account</button>
          </div>
        </div>
      </div>
    </>
  );
}

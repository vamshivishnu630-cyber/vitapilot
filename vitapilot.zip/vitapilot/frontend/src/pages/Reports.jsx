import { useEffect, useState } from "react";
import { Trash2, Upload } from "lucide-react";
import { api } from "../api.js";
import { useApp } from "../store.jsx";
import { LANGS, PageHead } from "../components/Layout.jsx";
import Markdown from "../components/Markdown.jsx";
import { StatusBadge } from "../components/Badge.jsx";

const SAMPLE = `CITY DIAGNOSTICS - COMPREHENSIVE HEALTH CHECK
Patient: Sample Patient    Date: 2026-09-15
Hemoglobin 11.2 g/dL (12.0-17.5)
Fasting Blood Sugar 112 mg/dL (70-99)
HbA1c 6.1 % (4.0-5.6)
Total Cholesterol 232 mg/dL (0-200)
LDL Cholesterol 151 mg/dL (0-100)
HDL Cholesterol 38 mg/dL (40-100)
Triglycerides 198 mg/dL (0-150)
Creatinine 0.9 mg/dL (0.6-1.3)
TSH 2.8 uIU/mL (0.4-4.5)
Vitamin D 17 ng/mL (30-100)
Vitamin B12 188 pg/mL (200-900)`;

export default function Reports() {
  const { profile, profileId } = useApp();
  const [list, setList] = useState([]);
  const [open, setOpen] = useState(null);
  const [form, setForm] = useState({ title: "", date: "", text: "", file: null, language: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const load = () => api.reports(profileId).then(setList).catch((e) => setErr(e.message));
  useEffect(() => { if (profileId) { load(); setOpen(null); } }, [profileId]);

  const submit = async (e) => {
    e.preventDefault(); setErr(""); setBusy(true);
    const fd = new FormData();
    fd.append("title", form.title); fd.append("report_date", form.date);
    fd.append("language", form.language || profile?.language || "en"); fd.append("text", form.text);
    if (form.file) fd.append("file", form.file);
    try {
      const r = await api.uploadReport(profileId, fd);
      setOpen(r); setForm({ title: "", date: "", text: "", file: null, language: "" }); e.target.reset(); load();
    } catch (ex) { setErr(ex.message); } finally { setBusy(false); }
  };

  const view = async (id) => setOpen(await api.report(id));
  const remove = async (id) => { if (confirm("Delete this report and its results?")) { await api.deleteReport(id); setOpen(null); load(); } };
  const reexplain = async (lang) => { const r = await api.explain(open.id, lang); setOpen({ ...open, summary: r.summary }); };

  return (
    <>
      <PageHead title="Reports" sub="Upload a PDF, photo or text. VitaMind extracts every result and explains it in plain language." />
      <div className="grid g2" style={{ alignItems: "start" }}>
        <div className="grid">
          <form className="card" onSubmit={submit}>
            <h2 style={{ marginBottom: 12 }}>Add a report</h2>
            <div className="grid g2">
              <div className="field"><label>Title</label><input placeholder="e.g. Annual health check" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
              <div className="field"><label>Report date</label><input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} /></div>
            </div>
            <div className="field"><label>File (PDF, image or .txt)</label><input type="file" accept=".pdf,.txt,.png,.jpg,.jpeg,.webp" onChange={(e) => setForm({ ...form, file: e.target.files[0] })} /></div>
            <div className="field">
              <div className="row between"><label>...or paste report text</label><button type="button" className="chip" onClick={() => setForm({ ...form, text: SAMPLE, title: form.title || "Sample health check" })}>Use sample report</button></div>
              <textarea rows={7} value={form.text} onChange={(e) => setForm({ ...form, text: e.target.value })} />
            </div>
            <div className="field"><label>Explain in</label>
              <select value={form.language || profile?.language || "en"} onChange={(e) => setForm({ ...form, language: e.target.value })}>
                {LANGS.map(([c, n]) => <option key={c} value={c}>{n}</option>)}
              </select>
            </div>
            {err && <div className="alert err" style={{ marginBottom: 10 }}>{err}</div>}
            <button className="btn" disabled={busy}><Upload size={16} /> {busy ? "Analysing..." : "Analyse report"}</button>
          </form>

          <div className="card">
            <h2 style={{ marginBottom: 10 }}>Your reports</h2>
            <div className="list">
              {list.length === 0 && <div className="muted">No reports yet.</div>}
              {list.map((r) => (
                <div key={r.id} className="item click" onClick={() => view(r.id)}>
                  <div><strong>{r.title}</strong><div className="muted">{r.report_date} - {r.lab_count} results</div></div>
                  <button className="btn ghost sm" onClick={(e) => { e.stopPropagation(); remove(r.id); }}><Trash2 size={14} /></button>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="card">
          {!open ? <div className="muted">Select or upload a report to see the AI explanation.</div> : (
            <>
              <div className="row between"><h2>{open.title}</h2>
                <select style={{ width: "auto" }} defaultValue="" onChange={(e) => e.target.value && reexplain(e.target.value)}>
                  <option value="">Re-explain in...</option>{LANGS.map(([c, n]) => <option key={c} value={c}>{n}</option>)}
                </select>
              </div>
              <div style={{ margin: "10px 0 14px" }}><Markdown text={open.summary} /></div>
              {open.labs?.length > 0 && (
                <table><thead><tr><th>Test</th><th>Result</th><th>Range</th><th>Status</th></tr></thead><tbody>
                  {open.labs.map((l) => (
                    <tr key={l.id}><td>{l.test_name}</td><td>{l.value} {l.unit}</td><td className="muted">{l.ref_low ?? "-"} to {l.ref_high ?? "-"}</td><td><StatusBadge status={l.status} /></td></tr>
                  ))}
                </tbody></table>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
}

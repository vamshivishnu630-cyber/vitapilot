from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import User
from ..security import get_current_user
from .profiles import profile_dict
from .reports import lab_dict, report_dict
from .medicines import med_dict

router = APIRouter(prefix="/api/privacy", tags=["privacy"])


@router.get("/export")
def export_data(user: User = Depends(get_current_user)):
    """Download everything VitaPilot stores about you (data portability)."""
    return {"user": {"name": user.name, "email": user.email},
            "profiles": [{**profile_dict(p),
                          "reports": [report_dict(r, full=True) for r in p.reports],
                          "labs": [lab_dict(l) for l in p.labs],
                          "medicines": [med_dict(m) for m in p.medicines]} for p in user.profiles]}


@router.delete("/account")
def delete_account(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """Permanently delete the account and all health data."""
    db.delete(user)
    db.commit()
    return {"ok": True, "message": "Your account and all data were deleted."}

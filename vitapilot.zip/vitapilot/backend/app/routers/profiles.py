from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import Medicine, Profile, User
from ..schemas import ProfileIn
from ..security import get_current_user, owned_profile

router = APIRouter(prefix="/api/profiles", tags=["profiles"])


def profile_dict(p: Profile):
    return {"id": p.id, "name": p.name, "relation": p.relation, "dob": p.dob.isoformat() if p.dob else None,
            "sex": p.sex, "language": p.language, "blood_group": p.blood_group, "allergies": p.allergies,
            "conditions": p.conditions, "emergency_contact": p.emergency_contact}


@router.get("")
def list_profiles(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return [profile_dict(p) for p in db.query(Profile).filter(Profile.user_id == user.id).order_by(Profile.id)]


@router.post("")
def create_profile(data: ProfileIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = Profile(user_id=user.id, **data.model_dump())
    db.add(p)
    db.commit()
    db.refresh(p)
    return profile_dict(p)


@router.put("/{pid}")
def update_profile(pid: int, data: ProfileIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = owned_profile(pid, user, db)
    for k, v in data.model_dump().items():
        setattr(p, k, v)
    db.commit()
    return profile_dict(p)


@router.delete("/{pid}")
def delete_profile(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = owned_profile(pid, user, db)
    if db.query(Profile).filter(Profile.user_id == user.id).count() <= 1:
        raise HTTPException(400, "You must keep at least one profile")
    db.delete(p)
    db.commit()
    return {"ok": True}


@router.get("/{pid}/emergency-card")
def emergency_card(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    p = owned_profile(pid, user, db)
    meds = db.query(Medicine).filter(Medicine.profile_id == pid, Medicine.active.is_(True)).all()
    return {**profile_dict(p), "medicines": [f"{m.name} {m.dose}".strip() for m in meds]}

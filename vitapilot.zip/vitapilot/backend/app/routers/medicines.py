from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from ..database import get_db
from ..models import DoseLog, Medicine, User
from ..reference import check_interactions
from ..schemas import DoseIn, MedicineIn
from ..security import get_current_user, owned_profile

router = APIRouter(prefix="/api", tags=["medicines"])


def med_dict(m: Medicine):
    return {"id": m.id, "name": m.name, "dose": m.dose, "times": m.times, "notes": m.notes, "active": m.active,
            "start_date": m.start_date.isoformat() if m.start_date else None,
            "end_date": m.end_date.isoformat() if m.end_date else None}


def owned_med(mid: int, user: User, db: Session) -> Medicine:
    m = db.get(Medicine, mid)
    if not m:
        raise HTTPException(404, "Medicine not found")
    owned_profile(m.profile_id, user, db)
    return m


@router.get("/profiles/{pid}/medicines")
def list_meds(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    return [med_dict(m) for m in db.query(Medicine).filter(Medicine.profile_id == pid).order_by(Medicine.active.desc(), Medicine.name)]


@router.post("/profiles/{pid}/medicines")
def add_med(pid: int, data: MedicineIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    payload = data.model_dump()
    payload["start_date"] = payload["start_date"] or date.today()
    m = Medicine(profile_id=pid, **payload)
    db.add(m)
    db.commit()
    db.refresh(m)
    return med_dict(m)


@router.put("/medicines/{mid}")
def update_med(mid: int, data: MedicineIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    m = owned_med(mid, user, db)
    for k, v in data.model_dump().items():
        if k == "start_date" and v is None:
            continue
        setattr(m, k, v)
    db.commit()
    return med_dict(m)


@router.delete("/medicines/{mid}")
def delete_med(mid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    db.delete(owned_med(mid, user, db))
    db.commit()
    return {"ok": True}


@router.post("/medicines/{mid}/log")
def log_dose(mid: int, data: DoseIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    m = owned_med(mid, user, db)
    today = date.today()
    row = db.query(DoseLog).filter(DoseLog.medicine_id == m.id, DoseLog.day == today, DoseLog.time == data.time).first()
    if row:
        row.taken = data.taken
    else:
        db.add(DoseLog(medicine_id=m.id, day=today, time=data.time, taken=data.taken))
    db.commit()
    return {"ok": True}


@router.get("/profiles/{pid}/reminders/today")
def today_doses(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    today = date.today()
    out = []
    for m in db.query(Medicine).filter(Medicine.profile_id == pid, Medicine.active.is_(True)).all():
        if m.end_date and m.end_date < today:
            continue
        for t in [x.strip() for x in m.times.split(",") if x.strip()]:
            log = db.query(DoseLog).filter(DoseLog.medicine_id == m.id, DoseLog.day == today, DoseLog.time == t).first()
            out.append({"medicine_id": m.id, "name": m.name, "dose": m.dose, "time": t, "taken": bool(log and log.taken)})
    return sorted(out, key=lambda x: x["time"])


@router.get("/profiles/{pid}/interactions")
def interactions(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    names = [m.name for m in db.query(Medicine).filter(Medicine.profile_id == pid, Medicine.active.is_(True))]
    return check_interactions(names)

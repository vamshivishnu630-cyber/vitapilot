from datetime import date, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from ..database import get_db
from ..llm import vitamind
from ..models import DoseLog, LabResult, Medicine, Report, User
from ..reference import detect_patterns
from ..schemas import VisitIn
from ..security import get_current_user, owned_profile
from .profiles import profile_dict

router = APIRouter(prefix="/api/profiles/{pid}", tags=["insights"])


def latest_labs(db: Session, pid: int):
    """Latest and previous value for each test."""
    rows = db.query(LabResult).filter(LabResult.profile_id == pid).order_by(LabResult.taken_on, LabResult.id).all()
    by = {}
    for r in rows:
        by.setdefault(r.test_name, []).append(r)
    return by


def vita_score(latest_status: list):
    """Share of latest results inside range (0-100), with extra weight for critical values."""
    if not latest_status:
        return None
    pts = 0.0
    for s in latest_status:
        pts += 1.0 if s == "normal" else (0.4 if s in ("low", "high") else 0.0)
    return round(100 * pts / len(latest_status))


@router.get("/dashboard")
def dashboard(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    by = latest_labs(db, pid)
    latest = {name: rows[-1] for name, rows in by.items()}
    flagged = []
    for name, row in latest.items():
        prev = by[name][-2] if len(by[name]) > 1 else None
        trend = None
        if prev:
            trend = "up" if row.value > prev.value else "down" if row.value < prev.value else "flat"
        if row.status != "normal":
            flagged.append({"test_name": name, "value": row.value, "unit": row.unit, "status": row.status,
                            "ref_low": row.ref_low, "ref_high": row.ref_high, "trend": trend, "taken_on": row.taken_on.isoformat()})
    patterns = detect_patterns({n: r.status for n, r in latest.items()})

    # medication adherence over the last 7 days
    since = date.today() - timedelta(days=6)
    expected = taken = 0
    for m in db.query(Medicine).filter(Medicine.profile_id == pid, Medicine.active.is_(True)).all():
        per_day = len([t for t in m.times.split(",") if t.strip()])
        days = (date.today() - max(m.start_date or since, since)).days + 1
        expected += per_day * max(days, 0)
        taken += db.query(DoseLog).filter(DoseLog.medicine_id == m.id, DoseLog.day >= since, DoseLog.taken.is_(True)).count()
    adherence = min(100, round(100 * taken / expected)) if expected else None

    return {"vita_score": vita_score([r.status for r in latest.values()]), "tests_tracked": len(latest),
            "flagged": flagged, "patterns": patterns, "adherence_7d": adherence,
            "counts": {"reports": db.query(Report).filter(Report.profile_id == pid).count(),
                       "medicines": db.query(Medicine).filter(Medicine.profile_id == pid, Medicine.active.is_(True)).count()},
            "ai_mode": vitamind.mode}


@router.get("/timeline")
def timeline(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    events = []
    for r in db.query(Report).filter(Report.profile_id == pid):
        events.append({"date": r.report_date.isoformat(), "type": "report", "title": r.title, "detail": f"{len(r.labs)} results"})
    for m in db.query(Medicine).filter(Medicine.profile_id == pid):
        if m.start_date:
            events.append({"date": m.start_date.isoformat(), "type": "medicine", "title": f"Started {m.name}", "detail": m.dose})
    for l in db.query(LabResult).filter(LabResult.profile_id == pid, LabResult.status != "normal"):
        events.append({"date": l.taken_on.isoformat(), "type": "alert", "title": f"{l.test_name} {l.status.replace('_', ' ')}", "detail": f"{l.value:g} {l.unit}"})
    return sorted(events, key=lambda e: e["date"], reverse=True)[:40]


@router.post("/visit-prep")
def visit_prep(pid: int, data: VisitIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = owned_profile(pid, user, db)
    by = latest_labs(db, pid)
    labs = [{"test_name": n, "value": rows[-1].value, "unit": rows[-1].unit, "status": rows[-1].status, "taken_on": rows[-1].taken_on.isoformat()} for n, rows in by.items()]
    labs.sort(key=lambda l: l["status"] == "normal")
    meds = [{"name": m.name, "dose": m.dose, "times": m.times} for m in db.query(Medicine).filter(Medicine.profile_id == pid, Medicine.active.is_(True))]
    reports = [{"title": r.title, "report_date": r.report_date.isoformat()} for r in db.query(Report).filter(Report.profile_id == pid).order_by(Report.report_date.desc()).limit(10)]
    brief = vitamind.visit_prep(profile_dict(profile), labs, meds, reports, data.reason, data.language or profile.language)
    return {"brief": brief}

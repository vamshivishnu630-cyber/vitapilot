import io
from datetime import date, datetime
from typing import Optional

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from sqlalchemy.orm import Session

from ..config import settings
from ..database import get_db
from ..llm import vitamind
from ..models import LabResult, Profile, Report, User
from ..reference import classify, normalize_name, ref_for
from ..schemas import ExplainIn, LabIn
from ..security import get_current_user, owned_profile

router = APIRouter(prefix="/api", tags=["reports"])


def lab_dict(l: LabResult):
    return {"id": l.id, "report_id": l.report_id, "test_name": l.test_name, "value": l.value, "unit": l.unit,
            "ref_low": l.ref_low, "ref_high": l.ref_high, "status": l.status, "taken_on": l.taken_on.isoformat()}


def report_dict(r: Report, full=False):
    d = {"id": r.id, "title": r.title, "report_type": r.report_type, "report_date": r.report_date.isoformat(),
         "filename": r.filename, "summary": r.summary, "lab_count": len(r.labs)}
    if full:
        d["raw_text"] = r.raw_text
        d["labs"] = [lab_dict(l) for l in sorted(r.labs, key=lambda x: x.test_name)]
    return d


def make_lab(profile_id, report_id, item, taken_on) -> Optional[LabResult]:
    try:
        name = normalize_name(item["test_name"])
        value = float(item["value"])
    except (KeyError, ValueError, TypeError):
        return None
    ref = ref_for(name)
    low = item.get("ref_low") if item.get("ref_low") is not None else (ref[0] if ref else None)
    high = item.get("ref_high") if item.get("ref_high") is not None else (ref[1] if ref else None)
    unit = item.get("unit") or (ref[2] if ref else "")
    return LabResult(profile_id=profile_id, report_id=report_id, test_name=name, value=value, unit=unit,
                     ref_low=low, ref_high=high, status=classify(name, value, low, high), taken_on=taken_on)


def extract_text(upload: UploadFile, data: bytes) -> str:
    name = (upload.filename or "").lower()
    ctype = upload.content_type or ""
    if name.endswith(".pdf") or ctype == "application/pdf":
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(data))
        return "\n".join((p.extract_text() or "") for p in reader.pages).strip()
    if ctype.startswith("image/") or name.endswith((".png", ".jpg", ".jpeg", ".webp")):
        media = ctype if ctype.startswith("image/") else "image/jpeg"
        return vitamind.read_image(data, media)
    return data.decode("utf-8", errors="ignore")


@router.post("/profiles/{pid}/reports")
async def upload_report(pid: int, title: str = Form(""), report_date: str = Form(""), language: str = Form(""),
                        text: str = Form(""), file: Optional[UploadFile] = File(None),
                        user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = owned_profile(pid, user, db)
    raw, filename = text, ""
    if file is not None and file.filename:
        data = await file.read()
        if len(data) > settings.MAX_UPLOAD_MB * 1024 * 1024:
            raise HTTPException(413, f"File too large (max {settings.MAX_UPLOAD_MB} MB)")
        filename = file.filename
        try:
            raw = extract_text(file, data)
        except ValueError as e:
            raise HTTPException(422, str(e))
        except Exception:
            raise HTTPException(422, "Could not read this file. Try a text-based PDF or paste the text.")
    if not raw.strip():
        raise HTTPException(422, "No readable text found. Upload a PDF/text file or paste the report text.")
    try:
        rdate = datetime.strptime(report_date, "%Y-%m-%d").date() if report_date else date.today()
    except ValueError:
        rdate = date.today()

    report = Report(profile_id=pid, title=title.strip() or filename or "Health report", report_date=rdate,
                    filename=filename, raw_text=raw)
    db.add(report)
    db.flush()
    for item in vitamind.extract_labs(raw):
        lab = make_lab(pid, report.id, item, rdate)
        if lab:
            db.add(lab)
    db.flush()
    db.refresh(report)
    labs = [lab_dict(l) for l in report.labs]
    report.summary = vitamind.explain_report(report.title, labs, raw, language or profile.language)
    db.commit()
    db.refresh(report)
    return report_dict(report, full=True)


@router.get("/profiles/{pid}/reports")
def list_reports(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    rows = db.query(Report).filter(Report.profile_id == pid).order_by(Report.report_date.desc(), Report.id.desc()).all()
    return [report_dict(r) for r in rows]


def owned_report(rid: int, user: User, db: Session) -> Report:
    r = db.get(Report, rid)
    if not r:
        raise HTTPException(404, "Report not found")
    owned_profile(r.profile_id, user, db)
    return r


@router.get("/reports/{rid}")
def get_report(rid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return report_dict(owned_report(rid, user, db), full=True)


@router.post("/reports/{rid}/explain")
def re_explain(rid: int, data: ExplainIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = owned_report(rid, user, db)
    profile = db.get(Profile, r.profile_id)
    r.summary = vitamind.explain_report(r.title, [lab_dict(l) for l in r.labs], r.raw_text, data.language or profile.language)
    db.commit()
    return {"summary": r.summary}


@router.delete("/reports/{rid}")
def delete_report(rid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    r = owned_report(rid, user, db)
    db.delete(r)
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- labs
@router.get("/profiles/{pid}/labs")
def list_labs(pid: int, test: str = "", user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    q = db.query(LabResult).filter(LabResult.profile_id == pid)
    if test:
        q = q.filter(LabResult.test_name == test)
    return [lab_dict(l) for l in q.order_by(LabResult.taken_on, LabResult.id)]


@router.get("/profiles/{pid}/labs/tests")
def lab_tests(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    names = [r[0] for r in db.query(LabResult.test_name).filter(LabResult.profile_id == pid).distinct().order_by(LabResult.test_name)]
    return names


@router.post("/profiles/{pid}/labs")
def add_lab(pid: int, data: LabIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    lab = make_lab(pid, None, {"test_name": data.test_name, "value": data.value, "unit": data.unit}, data.taken_on or date.today())
    if not lab:
        raise HTTPException(422, "Invalid lab value")
    db.add(lab)
    db.commit()
    db.refresh(lab)
    return lab_dict(lab)


@router.delete("/labs/{lid}")
def delete_lab(lid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    lab = db.get(LabResult, lid)
    if not lab:
        raise HTTPException(404, "Not found")
    owned_profile(lab.profile_id, user, db)
    db.delete(lab)
    db.commit()
    return {"ok": True}

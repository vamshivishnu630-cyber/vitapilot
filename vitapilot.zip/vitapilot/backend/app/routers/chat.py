import json
import re

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from .. import rag
from ..database import get_db
from ..llm import vitamind
from ..models import ChatMessage, LabResult, Medicine, Report, User
from ..safety import check_message
from ..schemas import ChatIn
from ..security import get_current_user, owned_profile

router = APIRouter(prefix="/api/profiles/{pid}/chat", tags=["copilot"])


def build_user_chunks(db: Session, profile) -> list:
    """Turn the person's own records into retrievable chunks."""
    chunks = []
    if profile.conditions or profile.allergies:
        chunks.append({"source": "Your profile", "text": f"Conditions: {profile.conditions or 'none recorded'}. Allergies: {profile.allergies or 'none recorded'}. Blood group: {profile.blood_group or 'unknown'}."})
    history = {}
    for l in db.query(LabResult).filter(LabResult.profile_id == profile.id).order_by(LabResult.taken_on, LabResult.id):
        history.setdefault(l.test_name, []).append(l)
    for name, rows in history.items():
        pts = "; ".join(f"{r.taken_on}: {r.value:g} {r.unit} ({r.status.replace('_', ' ')}, ref {r.ref_low}-{r.ref_high})" for r in rows[-6:])
        chunks.append({"source": "Your lab results", "text": f"{name} history: {pts}"})
    for m in db.query(Medicine).filter(Medicine.profile_id == profile.id, Medicine.active.is_(True)):
        chunks.append({"source": "Your medicines", "text": f"Medicine: {m.name} {m.dose}, taken at {m.times}. {m.notes}"})
    for r in db.query(Report).filter(Report.profile_id == profile.id).order_by(Report.report_date.desc()).limit(10):
        lines = [x for x in r.raw_text.splitlines() if x.strip()]
        for i in range(0, min(len(lines), 80), 8):
            chunks.append({"source": f"Your report: {r.title}", "text": " ".join(lines[i:i + 8])})
        if r.summary:
            chunks.append({"source": f"Your report: {r.title}", "text": r.summary[:900]})
    return chunks


@router.get("")
def history(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    rows = db.query(ChatMessage).filter(ChatMessage.profile_id == pid).order_by(ChatMessage.id).limit(100).all()
    return [{"role": m.role, "content": m.content, "sources": json.loads(m.sources) if m.sources else []} for m in rows]


@router.delete("")
def clear(pid: int, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    owned_profile(pid, user, db)
    db.query(ChatMessage).filter(ChatMessage.profile_id == pid).delete()
    db.commit()
    return {"ok": True}


@router.post("")
def ask(pid: int, data: ChatIn, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    profile = owned_profile(pid, user, db)
    db.add(ChatMessage(profile_id=pid, role="user", content=data.message))
    db.flush()  # so the current question is part of the history query below

    kind, canned = check_message(data.message)
    if kind:
        db.add(ChatMessage(profile_id=pid, role="assistant", content=canned))
        db.commit()
        return {"answer": canned, "sources": [], "flag": kind, "mode": vitamind.mode}

    pool = build_user_chunks(db, profile) + rag.knowledge()
    context = rag.search(data.message, pool, k=6)
    past = db.query(ChatMessage).filter(ChatMessage.profile_id == pid).order_by(ChatMessage.id.desc()).limit(9).all()
    hist = [{"role": m.role, "content": m.content} for m in reversed(past[1:])]
    answer = vitamind.chat(data.message, context, hist, data.language or profile.language, profile.name)
    sources = sorted({c["source"] for c in context})
    db.add(ChatMessage(profile_id=pid, role="assistant", content=answer, sources=json.dumps(sources)))
    db.commit()
    return {"answer": answer, "sources": sources, "flag": None, "mode": vitamind.mode}

"""VitaMind - the domain-specific AI engine behind VitaPilot.

VitaMind = Claude (or any LLM) + safety layer + RAG over the person's own records
+ a health-specific system prompt + structured-output extraction.
If no API key is set it falls back to deterministic DEMO MODE so the app still works.
"""
import base64
import json
import re
from datetime import date

from .config import settings
from .reference import REFERENCE, classify, normalize_name, _ALIAS
from .safety import DISCLAIMER

LANGUAGES = {"en": "English", "hi": "Hindi", "te": "Telugu", "ta": "Tamil", "bn": "Bengali",
             "mr": "Marathi", "kn": "Kannada", "ml": "Malayalam", "gu": "Gujarati"}

SYSTEM = """You are VitaMind, the health copilot inside VitaPilot.
Your job: help a person understand, organise and manage their healthcare journey.

Rules you must always follow:
1. You are NOT a doctor. Never diagnose, never prescribe, never change doses. Explain, organise and suggest questions for a clinician.
2. Ground answers in the RECORDS provided. If a value is not in the records, say you do not have it. Never invent numbers.
3. Use simple, calm, plain language (reading level of a 12 year old). Define any medical term you use.
4. Point out which result or record you are referring to.
5. For anything that sounds urgent, tell the person to contact a doctor or call 112/108 in India.
6. Keep answers short and structured. End with one practical next step.
7. Reply in the language requested by the user."""


class VitaMind:
    def __init__(self):
        self.client = None
        if settings.ANTHROPIC_API_KEY:
            try:
                import anthropic
                self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
            except Exception:
                self.client = None

    @property
    def available(self) -> bool:
        return self.client is not None

    @property
    def mode(self) -> str:
        return "claude" if self.available else "demo"

    # ------------------------------------------------------------------ core call
    def _call(self, system: str, messages: list, max_tokens: int = 1200) -> str:
        resp = self.client.messages.create(model=settings.CLAUDE_MODEL, max_tokens=max_tokens,
                                           system=system, messages=messages)
        return "".join(b.text for b in resp.content if getattr(b, "type", "") == "text").strip()

    def _lang(self, code: str) -> str:
        return LANGUAGES.get(code or "en", "English")

    # ------------------------------------------------------------------ OCR / vision
    def read_image(self, data: bytes, media_type: str) -> str:
        if not self.available:
            raise ValueError("Image reading needs an AI key. Upload a PDF or text file, or paste the text instead.")
        b64 = base64.b64encode(data).decode()
        msg = [{"role": "user", "content": [
            {"type": "image", "source": {"type": "base64", "media_type": media_type, "data": b64}},
            {"type": "text", "text": "Transcribe all text in this medical document exactly. Keep test names, values, units and reference ranges. Output plain text only."}]}]
        return self._call("You are an accurate OCR engine for medical documents.", msg, 2500)

    # ------------------------------------------------------------------ lab extraction
    def extract_labs(self, text: str) -> list:
        """Return [{test_name, value, unit, ref_low, ref_high}]."""
        if self.available:
            try:
                prompt = ("Extract every numeric lab result from this report. Return ONLY a JSON array, no prose. "
                          'Each item: {"test_name": str, "value": number, "unit": str, "ref_low": number|null, "ref_high": number|null}.\n\n'
                          + text[:12000])
                raw = self._call("You extract structured data from medical reports. Output valid JSON only.",
                                 [{"role": "user", "content": prompt}], 2500)
                raw = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip()
                items = json.loads(raw)
                return [i for i in items if isinstance(i.get("value"), (int, float))]
            except Exception:
                pass
        return parse_labs_regex(text)

    # ------------------------------------------------------------------ explain report
    def explain_report(self, title: str, labs: list, text: str, language: str = "en") -> str:
        if self.available:
            lab_lines = "\n".join(f"- {l['test_name']}: {l['value']} {l.get('unit','')} (ref {l.get('ref_low')}-{l.get('ref_high')}, {l['status']})" for l in labs)
            prompt = (f"Explain this report to the patient in {self._lang(language)}.\n"
                      f"Title: {title}\nResults:\n{lab_lines or '(none extracted)'}\n\nOriginal text:\n{text[:5000]}\n\n"
                      "Format: 1) A two-line overall summary. 2) What is normal. 3) What needs attention and what it generally means. "
                      "4) Three questions to ask the doctor. Do not diagnose.")
            try:
                return self._call(SYSTEM, [{"role": "user", "content": prompt}], 1400)
            except Exception:
                pass
        return demo_explain(title, labs)

    # ------------------------------------------------------------------ chat
    def chat(self, question: str, context: list, history: list, language: str, profile_name: str) -> str:
        ctx = "\n\n".join(f"[{c['source']}]\n{c['text']}" for c in context) or "(no matching records)"
        if self.available:
            msgs = [{"role": h["role"], "content": h["content"]} for h in history[-8:]]
            msgs.append({"role": "user", "content": f"Person: {profile_name}\nLanguage: {self._lang(language)}\n\nRECORDS:\n{ctx}\n\nQUESTION: {question}"})
            try:
                return self._call(SYSTEM, msgs, 900)
            except Exception as e:
                return f"I couldn't reach the AI service ({type(e).__name__}). Here is what I found in your records:\n\n" + demo_chat(context)
        return demo_chat(context)

    # ------------------------------------------------------------------ visit prep
    def visit_prep(self, profile: dict, labs: list, meds: list, reports: list, reason: str, language: str) -> str:
        data = visit_data_text(profile, labs, meds, reports, reason)
        if self.available:
            prompt = (f"Write a one-page doctor visit brief in {self._lang(language)} from this data.\n\n{data}\n\n"
                      "Sections: Reason for visit, Key results (flag abnormal), Current medicines, Allergies/conditions, "
                      "Changes since last visit, 6 smart questions to ask. Be concise, use markdown, do not diagnose.")
            try:
                return self._call(SYSTEM, [{"role": "user", "content": prompt}], 1500)
            except Exception:
                pass
        return demo_visit(profile, labs, meds, reason)


# ====================================================================== helpers / demo mode
LINE_RE = re.compile(
    r"^\s*(?P<name>[A-Za-z][A-Za-z0-9 \-\(\)/\.]{1,40}?)\s*[:\-]?\s+(?P<value>\d+(?:\.\d+)?)\s*"
    r"(?P<unit>[A-Za-z%/\^0-9µ]+(?:/[A-Za-z0-9µ]+)?)?\s*(?:[\(\[]?\s*(?:ref(?:erence)?\.?:?\s*)?(?P<lo>\d+(?:\.\d+)?)\s*[-–to]+\s*(?P<hi>\d+(?:\.\d+)?)\s*[\)\]]?)?\s*$",
    re.I)


def parse_labs_regex(text: str) -> list:
    out, seen = [], set()
    for line in text.splitlines():
        m = LINE_RE.match(line)
        if not m:
            continue
        raw_name = m.group("name").strip(" :-")
        canon = _ALIAS.get(re.sub(r"\s+", " ", raw_name.lower()))
        if not canon or canon in seen:
            continue
        seen.add(canon)
        ref = REFERENCE[canon]
        out.append({"test_name": canon, "value": float(m.group("value")),
                    "unit": (m.group("unit") or ref[2]),
                    "ref_low": float(m.group("lo")) if m.group("lo") else None,
                    "ref_high": float(m.group("hi")) if m.group("hi") else None})
    return out


STATUS_WORDS = {"low": "below range", "high": "above range", "normal": "in range",
                "critical_low": "critically low", "critical_high": "critically high"}


def demo_explain(title: str, labs: list) -> str:
    if not labs:
        return f"**{title}**\n\nI couldn't find numeric results to explain. Try pasting the report text or adding values manually."
    bad = [l for l in labs if l["status"] != "normal"]
    good = [l for l in labs if l["status"] == "normal"]
    lines = [f"**Summary:** {len(labs)} results found. {len(good)} in range, {len(bad)} need attention."]
    if good:
        lines.append("\n**In range:** " + ", ".join(l["test_name"] for l in good) + ".")
    if bad:
        lines.append("\n**Needs attention:**")
        for l in bad:
            lines.append(f"- {l['test_name']}: {l['value']} {l.get('unit','')} is {STATUS_WORDS[l['status']]}.")
    lines.append("\n**Ask your doctor:** What could explain these results? Do I need a repeat test? Should I change diet, activity or medicines?")
    lines.append(f"\n_{DISCLAIMER}_  \n_(Demo mode: connect an AI key for richer explanations and translation.)_")
    return "\n".join(lines)


def demo_chat(context: list) -> str:
    if not context:
        return ("I couldn't find anything about that in your records or my knowledge base. "
                "Try uploading a report or rephrasing the question.\n\n_" + DISCLAIMER + "_")
    parts = [f"**From {c['source']}:** {c['text'][:420]}" for c in context[:3]]
    return "\n\n".join(parts) + f"\n\n_{DISCLAIMER}_  \n_(Demo mode: connect an AI key for conversational answers.)_"


def visit_data_text(profile, labs, meds, reports, reason):
    lab_txt = "\n".join(f"- {l['test_name']}: {l['value']} {l.get('unit','')} on {l['taken_on']} ({l['status']})" for l in labs[:40])
    med_txt = "\n".join(f"- {m['name']} {m.get('dose','')} at {m.get('times','')}" for m in meds)
    rep_txt = "\n".join(f"- {r['title']} ({r['report_date']})" for r in reports[:10])
    return (f"Patient: {profile['name']}, DOB {profile.get('dob')}, sex {profile.get('sex')}\n"
            f"Allergies: {profile.get('allergies') or 'none recorded'}\nConditions: {profile.get('conditions') or 'none recorded'}\n"
            f"Reason for visit: {reason or 'general check-up'}\n\nRecent labs:\n{lab_txt}\n\nMedicines:\n{med_txt}\n\nReports:\n{rep_txt}")


def demo_visit(profile, labs, meds, reason):
    bad = [l for l in labs if l["status"] != "normal"]
    out = [f"# Doctor visit brief: {profile['name']}", f"**Reason for visit:** {reason or 'General check-up'}",
           f"**Allergies:** {profile.get('allergies') or 'None recorded'}  \n**Conditions:** {profile.get('conditions') or 'None recorded'}",
           "\n## Results to discuss"]
    out += [f"- {l['test_name']}: **{l['value']} {l.get('unit','')}** ({STATUS_WORDS[l['status']]}, {l['taken_on']})" for l in bad] or ["- Nothing out of range in recent results."]
    out.append("\n## Current medicines")
    out += [f"- {m['name']} {m.get('dose','')} ({m.get('times','')})" for m in meds] or ["- None recorded."]
    out += ["\n## Questions to ask", "1. What do my out-of-range results mean for me?", "2. Do I need repeat or follow-up tests, and when?",
            "3. Are my current medicines still right for me?", "4. What lifestyle changes would help most?",
            "5. Which symptoms mean I should come back sooner?", "6. When is my next check-up?",
            f"\n_{DISCLAIMER}_"]
    return "\n".join(out)


vitamind = VitaMind()

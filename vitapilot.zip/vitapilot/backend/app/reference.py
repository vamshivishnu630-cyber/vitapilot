"""Lab reference ranges, name normalisation, interaction rules and pattern detection.

Reference ranges are general adult values for demo/education purposes. Real labs print
their own ranges on the report - those always win when we can parse them.
"""
import re

# canonical name -> (low, high, unit, critical_low, critical_high, [aliases])
REFERENCE = {
    "Hemoglobin": (12.0, 17.5, "g/dL", 7.0, 20.0, ["hemoglobin", "haemoglobin", "hb", "hgb"]),
    "HbA1c": (4.0, 5.6, "%", None, 10.0, ["hba1c", "glycated hemoglobin", "glycosylated hemoglobin", "a1c"]),
    "Fasting Glucose": (70, 99, "mg/dL", 50, 300, ["fasting glucose", "fasting blood sugar", "fbs", "glucose fasting", "blood sugar fasting", "glucose"]),
    "Total Cholesterol": (0, 200, "mg/dL", None, None, ["total cholesterol", "cholesterol total", "cholesterol"]),
    "LDL Cholesterol": (0, 100, "mg/dL", None, None, ["ldl", "ldl cholesterol", "ldl-c"]),
    "HDL Cholesterol": (40, 100, "mg/dL", None, None, ["hdl", "hdl cholesterol", "hdl-c"]),
    "Triglycerides": (0, 150, "mg/dL", None, 500, ["triglycerides", "tg", "triglyceride"]),
    "Creatinine": (0.6, 1.3, "mg/dL", None, 5.0, ["creatinine", "serum creatinine"]),
    "Urea": (15, 45, "mg/dL", None, None, ["urea", "blood urea"]),
    "Uric Acid": (3.5, 7.2, "mg/dL", None, None, ["uric acid"]),
    "TSH": (0.4, 4.5, "uIU/mL", 0.01, 20.0, ["tsh", "thyroid stimulating hormone"]),
    "Vitamin D": (30, 100, "ng/mL", 10, None, ["vitamin d", "25-oh vitamin d", "vitamin d3", "25 hydroxy vitamin d"]),
    "Vitamin B12": (200, 900, "pg/mL", 150, None, ["vitamin b12", "b12", "cyanocobalamin"]),
    "WBC Count": (4.0, 11.0, "x10^3/uL", 2.0, 30.0, ["wbc", "total leucocyte count", "tlc", "white blood cell count", "wbc count"]),
    "Platelet Count": (150, 450, "x10^3/uL", 50, 1000, ["platelets", "platelet count", "plt"]),
    "ALT (SGPT)": (7, 56, "U/L", None, None, ["alt", "sgpt", "alanine aminotransferase"]),
    "AST (SGOT)": (10, 40, "U/L", None, None, ["ast", "sgot", "aspartate aminotransferase"]),
    "Sodium": (135, 145, "mmol/L", 120, 160, ["sodium", "na"]),
    "Potassium": (3.5, 5.1, "mmol/L", 2.8, 6.2, ["potassium", "k"]),
    "Ferritin": (30, 400, "ng/mL", None, None, ["ferritin"]),
}

_ALIAS = {}
for canon, row in REFERENCE.items():
    _ALIAS[canon.lower()] = canon
    for a in row[5]:
        _ALIAS[a.lower()] = canon


def normalize_name(name: str) -> str:
    key = re.sub(r"\s+", " ", (name or "").strip().lower())
    return _ALIAS.get(key, (name or "").strip().title() if name else "Unknown")


def ref_for(name: str):
    row = REFERENCE.get(normalize_name(name))
    return row


def classify(name: str, value: float, low=None, high=None) -> str:
    """Return low | normal | high | critical_low | critical_high."""
    row = ref_for(name)
    c_low = c_high = None
    if row:
        low = low if low is not None else row[0]
        high = high if high is not None else row[1]
        c_low, c_high = row[3], row[4]
    if c_low is not None and value <= c_low:
        return "critical_low"
    if c_high is not None and value >= c_high:
        return "critical_high"
    if low is not None and value < low:
        return "low"
    if high is not None and value > high:
        return "high"
    return "normal"


# ---- Medicine interaction rules (educational subset, NOT exhaustive) ----
INTERACTIONS = [
    ({"warfarin", "aspirin"}, "high", "Both thin the blood. Together they raise the risk of serious bleeding."),
    ({"warfarin", "ibuprofen"}, "high", "NSAIDs with warfarin increase bleeding risk."),
    ({"aspirin", "ibuprofen"}, "moderate", "Ibuprofen can weaken aspirin's heart-protective effect and both irritate the stomach."),
    ({"sildenafil", "nitroglycerin"}, "high", "This combination can cause a dangerous drop in blood pressure."),
    ({"simvastatin", "clarithromycin"}, "high", "Raises statin levels in blood and the risk of muscle damage."),
    ({"lisinopril", "potassium"}, "moderate", "ACE inhibitors plus potassium can push potassium levels too high."),
    ({"levothyroxine", "calcium"}, "moderate", "Calcium reduces levothyroxine absorption. Keep them about 4 hours apart."),
    ({"levothyroxine", "iron"}, "moderate", "Iron reduces levothyroxine absorption. Keep them about 4 hours apart."),
    ({"metformin", "alcohol"}, "moderate", "Alcohol with metformin raises the risk of lactic acidosis."),
    ({"ciprofloxacin", "antacid"}, "moderate", "Antacids reduce ciprofloxacin absorption. Space doses apart."),
    ({"sertraline", "tramadol"}, "high", "Raises the risk of serotonin syndrome and seizures."),
    ({"clopidogrel", "omeprazole"}, "moderate", "Omeprazole may reduce clopidogrel's effect."),
    ({"atorvastatin", "grapefruit"}, "low", "Large amounts of grapefruit juice can raise atorvastatin levels."),
]


def check_interactions(med_names):
    names = [re.sub(r"[^a-z ]", "", m.lower()).strip() for m in med_names]
    found = []
    for pair, severity, note in INTERACTIONS:
        a, b = tuple(pair)
        hit_a = [n for n in names if a in n]
        hit_b = [n for n in names if b in n]
        if hit_a and hit_b:
            found.append({"drugs": sorted([a.title(), b.title()]), "severity": severity, "note": note})
    order = {"high": 0, "moderate": 1, "low": 2}
    return sorted(found, key=lambda x: order[x["severity"]])


# ---- Pattern detector: rules that look ACROSS results ----
def detect_patterns(latest: dict):
    """latest: {canonical test name: status}. Returns plain-language pattern flags."""
    flags = []
    bad = lambda n: latest.get(n, "normal") != "normal"
    high = lambda n: latest.get(n, "normal") in ("high", "critical_high")
    low = lambda n: latest.get(n, "normal") in ("low", "critical_low")

    if high("HbA1c") or high("Fasting Glucose"):
        flags.append({"title": "Blood sugar control", "level": "attention",
                      "detail": "Glucose markers are above range. Worth discussing diabetes screening and lifestyle with your doctor."})
    if sum(high(n) for n in ("Total Cholesterol", "LDL Cholesterol", "Triglycerides")) >= 2 or (low("HDL Cholesterol") and bad("LDL Cholesterol")):
        flags.append({"title": "Cholesterol pattern", "level": "attention",
                      "detail": "Several lipid markers are off together, which matters more for heart health than a single value."})
    if low("Hemoglobin") and (low("Ferritin") or low("Vitamin B12")):
        flags.append({"title": "Possible nutritional anaemia pattern", "level": "attention",
                      "detail": "Low hemoglobin with low iron stores or B12 is a common pattern. A doctor can confirm the cause."})
    if bad("TSH"):
        flags.append({"title": "Thyroid marker out of range", "level": "attention",
                      "detail": "TSH is outside range. Thyroid tests are usually repeated and reviewed with a doctor."})
    if high("Creatinine") or high("Urea"):
        flags.append({"title": "Kidney markers", "level": "attention",
                      "detail": "Kidney-related markers are raised. Hydration, medicines and other factors can influence this, so follow up."})
    if high("ALT (SGPT)") or high("AST (SGOT)"):
        flags.append({"title": "Liver enzymes", "level": "attention",
                      "detail": "Liver enzymes are raised. Medicines, alcohol and fatty liver are common causes."})
    if low("Vitamin D"):
        flags.append({"title": "Low vitamin D", "level": "info",
                      "detail": "Very common. Safe sun exposure and doctor-guided supplements are typical next steps."})
    if any(v.startswith("critical") for v in latest.values()):
        flags.insert(0, {"title": "Critical value detected", "level": "urgent",
                         "detail": "At least one result is in a critical range. Contact your doctor promptly."})
    return flags

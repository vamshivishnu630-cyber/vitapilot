from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from .config import settings
from .database import Base, engine
from .llm import vitamind
from .routers import auth, chat, insights, medicines, privacy, profiles, reports

Base.metadata.create_all(bind=engine)

app = FastAPI(title="VitaPilot API", version="1.0.0",
              description="AI-powered personal health copilot: records, insights, reminders and a safe AI assistant.")

app.add_middleware(CORSMiddleware, allow_origins=settings.CORS_ORIGINS, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    return response


for r in (auth, profiles, reports, medicines, chat, insights, privacy):
    app.include_router(r.router)


@app.get("/api/health")
def health():
    return {"status": "ok", "ai_mode": vitamind.mode, "model": settings.CLAUDE_MODEL if vitamind.available else "demo-rules"}

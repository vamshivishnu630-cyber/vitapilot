Before a doctor visit: write down symptoms, when they began, what makes them better or worse, and all medicines and supplements you take. Bring recent reports and previous prescriptions.

Good questions to ask: What could be causing this? Which tests do I need and why? Are there side effects of the medicine? What should I do if it gets worse? When should I come back?

After the visit: note the diagnosis and plan in your own words, ask for a written prescription, and set reminders for follow-up tests.

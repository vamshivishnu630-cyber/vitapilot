Balanced eating: more vegetables, fruit, pulses, whole grains and nuts; less sugary drinks, deep fried food and ultra-processed snacks. Portion size matters as much as food type.

Physical activity: adults generally aim for about 150 minutes of moderate activity a week, such as brisk walking, plus muscle strengthening on 2 days.

Sleep: most adults need 7 to 9 hours. Poor sleep is linked to higher blood sugar, blood pressure and weight.

Blood pressure: below 120/80 is normal, 130/80 or above is considered high in many guidelines. Reduce salt, stay active and ask a doctor about regular monitoring.

Hydration and screening: drink water through the day. Adults should discuss routine screening for blood pressure, diabetes, cholesterol, vision, dental and age-appropriate cancer screening with their doctor.

Hemoglobin carries oxygen in red blood cells. Low hemoglobin is called anaemia and can cause tiredness, pale skin and breathlessness on exertion. Common causes include low iron, low vitamin B12 or folate, blood loss and chronic illness. A doctor decides the cause with more tests.

HbA1c reflects average blood sugar over about 3 months. Below 5.7 percent is generally normal, 5.7 to 6.4 percent is the prediabetes range and 6.5 percent or more is in the diabetes range on repeat testing. Fasting glucose below 100 mg/dL is normal, 100 to 125 is prediabetes range, 126 or higher on two tests suggests diabetes.

Cholesterol panel: LDL is the bad cholesterol, HDL is the protective cholesterol, and triglycerides are blood fats. Lower LDL and triglycerides and higher HDL are better for the heart. Fasting before the test makes triglycerides more accurate. Diet, exercise, weight and genetics all affect results.

TSH is the thyroid stimulating hormone. High TSH often points to an underactive thyroid (hypothyroidism) and low TSH to an overactive thyroid (hyperthyroidism). Doctors usually repeat the test and may check T3 and T4 before deciding on treatment.

Vitamin D below 20 ng/mL is considered deficient and 20 to 30 is insufficient in many guidelines. Low vitamin D is very common in India. Doctors usually advise sunlight, diet and sometimes supplements at a dose they prescribe.

Vitamin B12 is needed for nerves and blood cells. Low B12 can cause tingling, fatigue and anaemia. Vegetarians and people on metformin or acid-reducing medicines are at higher risk of low B12.

Creatinine and urea are waste products filtered by the kidneys. Raised values can indicate reduced kidney function, but dehydration, high protein intake, muscle mass and some medicines can also change them. Doctors often calculate eGFR.

ALT (SGPT) and AST (SGOT) are liver enzymes. They rise with fatty liver, viral hepatitis, alcohol, and some medicines. Mild rises are common and are usually rechecked.

Platelets help blood clot. Low platelets can occur in viral infections such as dengue, and some medicines. A very low count needs urgent medical review. WBC count rises with infection and inflammation.

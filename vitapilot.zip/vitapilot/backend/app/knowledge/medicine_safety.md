Take medicines exactly as prescribed. Do not stop antibiotics, blood pressure or diabetes medicines suddenly without asking your doctor or pharmacist.

If you miss a dose, check the leaflet or ask a pharmacist. In general, take it when you remember unless it is almost time for the next dose. Never double up unless a doctor tells you to.

Some medicines should be spaced apart. Thyroid tablets such as levothyroxine are usually taken on an empty stomach and kept about 4 hours from calcium or iron tablets.

NSAID pain killers such as ibuprofen and diclofenac can irritate the stomach and strain the kidneys. People with kidney disease, ulcers or those on blood thinners should ask a doctor before using them.

Keep an updated list of all medicines, supplements and herbal products and share it at every visit. Tell every doctor about your allergies.

Store medicines away from heat, moisture and children. Check expiry dates regularly.

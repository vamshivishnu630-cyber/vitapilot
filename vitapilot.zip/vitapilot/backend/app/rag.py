"""Tiny dependency-free BM25 retriever.

VitaMind retrieves from TWO sources and merges them:
  1. the curated medical knowledge base in app/knowledge/*.md
  2. the user's OWN records (reports, labs, medicines) - built fresh per question
This keeps answers grounded in the person's data instead of generic text.
"""
import math
import re
from collections import Counter
from pathlib import Path

KNOWLEDGE_DIR = Path(__file__).parent / "knowledge"
STOP = set("a an the and or of to in on for with is are was were be been it this that what why how do does my me i you your can should about from as at by".split())


def tokenize(text: str):
    return [w for w in re.findall(r"[a-z0-9\+]+", text.lower()) if w not in STOP and len(w) > 1]


def load_knowledge():
    chunks = []
    for path in sorted(KNOWLEDGE_DIR.glob("*.md")):
        text = path.read_text(encoding="utf-8")
        title = path.stem.replace("_", " ").title()
        for block in re.split(r"\n\s*\n", text):
            block = block.strip()
            if len(block) > 40:
                chunks.append({"source": f"Knowledge: {title}", "text": block})
    return chunks


_KB = None


def knowledge():
    global _KB
    if _KB is None:
        _KB = load_knowledge()
    return _KB


def search(query: str, chunks: list, k: int = 6):
    docs = [tokenize(c["text"]) for c in chunks]
    q = tokenize(query)
    if not docs or not q:
        return []
    n = len(docs)
    avg = sum(len(d) for d in docs) / n or 1
    df = Counter()
    for d in docs:
        for term in set(d):
            df[term] += 1
    scored = []
    for chunk, d in zip(chunks, docs):
        tf = Counter(d)
        score = 0.0
        for term in q:
            if term not in tf:
                continue
            idf = math.log(1 + (n - df[term] + 0.5) / (df[term] + 0.5))
            score += idf * (tf[term] * 2.2) / (tf[term] + 1.2 * (0.25 + 0.75 * len(d) / avg))
        if chunk["source"].startswith("Your "):
            score *= 1.4  # prefer the person's own data
        if score > 0:
            scored.append((score, chunk))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [c for _, c in scored[:k]]

from datetime import datetime, date

from sqlalchemy import Boolean, Column, Date, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship

from .database import Base


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    profiles = relationship("Profile", back_populates="user", cascade="all, delete-orphan")


class Profile(Base):
    """One person's health record. A user can manage several (self, parents, kids)."""
    __tablename__ = "profiles"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), index=True, nullable=False)
    name = Column(String(120), nullable=False)
    relation = Column(String(60), default="Self")
    dob = Column(Date, nullable=True)
    sex = Column(String(20), default="")
    language = Column(String(10), default="en")
    blood_group = Column(String(10), default="")
    allergies = Column(Text, default="")
    conditions = Column(Text, default="")
    emergency_contact = Column(String(200), default="")
    user = relationship("User", back_populates="profiles")
    reports = relationship("Report", back_populates="profile", cascade="all, delete-orphan")
    labs = relationship("LabResult", back_populates="profile", cascade="all, delete-orphan")
    medicines = relationship("Medicine", back_populates="profile", cascade="all, delete-orphan")
    messages = relationship("ChatMessage", back_populates="profile", cascade="all, delete-orphan")


class Report(Base):
    __tablename__ = "reports"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    title = Column(String(200), nullable=False)
    report_type = Column(String(60), default="Lab report")
    report_date = Column(Date, default=date.today)
    filename = Column(String(255), default="")
    raw_text = Column(Text, default="")
    summary = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    profile = relationship("Profile", back_populates="reports")
    labs = relationship("LabResult", back_populates="report", cascade="all, delete-orphan")


class LabResult(Base):
    __tablename__ = "lab_results"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    report_id = Column(Integer, ForeignKey("reports.id"), nullable=True)
    test_name = Column(String(120), index=True, nullable=False)
    value = Column(Float, nullable=False)
    unit = Column(String(40), default="")
    ref_low = Column(Float, nullable=True)
    ref_high = Column(Float, nullable=True)
    status = Column(String(20), default="normal")  # low | normal | high | critical_low | critical_high
    taken_on = Column(Date, default=date.today)
    profile = relationship("Profile", back_populates="labs")
    report = relationship("Report", back_populates="labs")


class Medicine(Base):
    __tablename__ = "medicines"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    name = Column(String(120), nullable=False)
    dose = Column(String(60), default="")
    times = Column(String(120), default="08:00")  # comma separated HH:MM
    notes = Column(Text, default="")
    start_date = Column(Date, default=date.today)
    end_date = Column(Date, nullable=True)
    active = Column(Boolean, default=True)
    profile = relationship("Profile", back_populates="medicines")
    logs = relationship("DoseLog", back_populates="medicine", cascade="all, delete-orphan")


class DoseLog(Base):
    __tablename__ = "dose_logs"
    id = Column(Integer, primary_key=True)
    medicine_id = Column(Integer, ForeignKey("medicines.id"), index=True, nullable=False)
    day = Column(Date, default=date.today)
    time = Column(String(5), default="08:00")
    taken = Column(Boolean, default=True)
    medicine = relationship("Medicine", back_populates="logs")


class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id = Column(Integer, primary_key=True)
    profile_id = Column(Integer, ForeignKey("profiles.id"), index=True, nullable=False)
    role = Column(String(12), nullable=False)  # user | assistant
    content = Column(Text, nullable=False)
    sources = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    profile = relationship("Profile", back_populates="messages")

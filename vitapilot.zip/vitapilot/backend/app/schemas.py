from datetime import date
from typing import Optional

from pydantic import BaseModel, EmailStr, Field


class RegisterIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class ProfileIn(BaseModel):
    name: str
    relation: str = "Self"
    dob: Optional[date] = None
    sex: str = ""
    language: str = "en"
    blood_group: str = ""
    allergies: str = ""
    conditions: str = ""
    emergency_contact: str = ""


class LabIn(BaseModel):
    test_name: str
    value: float
    unit: str = ""
    taken_on: Optional[date] = None


class MedicineIn(BaseModel):
    name: str
    dose: str = ""
    times: str = "08:00"
    notes: str = ""
    start_date: Optional[date] = None
    end_date: Optional[date] = None
    active: bool = True


class DoseIn(BaseModel):
    time: str = "08:00"
    taken: bool = True


class ChatIn(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    language: Optional[str] = None


class VisitIn(BaseModel):
    reason: str = ""
    language: Optional[str] = None


class ExplainIn(BaseModel):
    language: Optional[str] = None

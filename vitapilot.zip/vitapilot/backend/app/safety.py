"""Safety layer that runs BEFORE any AI answer is generated."""
import re

DISCLAIMER = ("VitaPilot gives general health information, not a diagnosis or treatment. "
              "Always confirm with a qualified doctor.")

EMERGENCY_PATTERNS = [
    r"chest (pain|tightness|pressure)", r"(can'?t|cannot|difficulty|trouble) breath", r"short(ness)? of breath",
    r"face droop|slurred speech|sudden (weakness|numbness)|stroke",
    r"severe bleeding|bleeding (a lot|heavily|won'?t stop)", r"unconscious|passed out|not responding",
    r"overdose|poison(ed|ing)?", r"seizure|convulsion", r"anaphyla|throat (swelling|closing)",
    r"heart attack",
]
SELF_HARM_PATTERNS = [r"suicid", r"kill myself", r"end my life", r"want to die", r"self[- ]harm", r"hurt myself"]

EMERGENCY_REPLY = (
    "**This could be a medical emergency.** Please do not wait for an app.\n\n"
    "- Call **112** (India national emergency) or **108** (ambulance) right now.\n"
    "- If someone is with you, ask them to stay with you and unlock the door for responders.\n"
    "- Do not drive yourself if you feel faint or have chest pain.\n\n"
    "Once you are safe, I can help you organise your records for the doctor."
)
SELF_HARM_REPLY = (
    "I'm really sorry you're feeling this way. You deserve support right now.\n\n"
    "- In India you can call **Tele-MANAS at 14416** (free, 24x7) or **112** in an emergency.\n"
    "- If you're elsewhere, please contact your local emergency number.\n"
    "- If you can, reach out to someone you trust and stay with them.\n\n"
    "I'm here to talk if you'd like, but please connect with a real person as well."
)


def check_message(text: str):
    """Return (kind, reply) where kind is 'emergency' | 'self_harm' | None."""
    t = (text or "").lower()
    if any(re.search(p, t) for p in SELF_HARM_PATTERNS):
        return "self_harm", SELF_HARM_REPLY
    if any(re.search(p, t) for p in EMERGENCY_PATTERNS):
        return "emergency", EMERGENCY_REPLY
    return None, None

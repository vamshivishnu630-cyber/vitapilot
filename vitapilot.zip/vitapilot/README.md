# VitaPilot - AI-Powered Personal Health Copilot

> Understand, organise and manage your healthcare journey, in plain language, in your own language.

Built for **Challenge 01: AI-Powered Personal Health Copilot** (Altrix Labs).

VitaPilot turns the pile of PDFs, photos and prescriptions most families keep into one private,
searchable health record, then adds an AI copilot (**VitaMind**) that explains results, spots patterns,
keeps medicines safe and prepares you for every doctor visit.

---

## What it does

| Challenge goal | VitaPilot feature |
|---|---|
| **Understand** | Upload a PDF/photo/text report. VitaMind extracts every lab value, compares it with the reference range and explains it in simple words in 9 Indian languages. |
| **Organise** | One timeline for reports, results and medicines. Family profiles for parents and kids. Lab trend charts against healthy ranges. |
| **Manage** | Medicine schedule with daily dose tracking, 7-day adherence, interaction warnings, doctor-visit briefs and an emergency card. |

## Unique features (what makes it stand out)

1. **VitaMind engine** - a domain-specific AI layer: Claude + safety layer + RAG over *your own records* + health system prompt + structured extraction. Works in **demo mode without any API key**.
2. **Vita Score** - one 0-100 number showing how many of your latest results are in range.
3. **Pattern Detector** - rules that look *across* results (e.g. low hemoglobin + low B12 + low ferritin, or a cluster of lipid markers) instead of judging each value alone.
4. **Safety layer before the AI** - emergency and self-harm phrases are intercepted and answered with India helplines (112 / 108 / Tele-MANAS 14416). The AI never diagnoses or changes doses.
5. **Grounded answers with sources** - every chat reply lists which of your records or which knowledge-base article it used. No invented numbers.
6. **Doctor Visit Prep** - one-page printable brief: key results, medicines, what changed, 6 smart questions.
7. **Multilingual** - English, Hindi, Telugu, Tamil, Bengali, Marathi, Kannada, Malayalam, Gujarati.
8. **Family profiles** - manage parents and children from one login, with an emergency card per person.
9. **Privacy by design** - ownership checks on every query, PBKDF2 password hashing, JWT sessions, one-click data export and permanent account deletion.
10. **Medication adherence + interaction checker** - dose log and a curated interaction rule set.

## Architecture

```
React (Vite)  --->  FastAPI  --->  PostgreSQL / SQLite
   Recharts          |
                     +--> Safety layer (emergency intercept)
                     +--> VitaMind: BM25 RAG (your records + knowledge base)
                     +--> Claude API  (or demo-mode rules if no key)
```

See `docs/ARCHITECTURE.md` for details and `docs/PITCH.md` for a 3-minute demo script.

## Tech stack

- **Frontend:** React 18, Vite, React Router, Recharts, Lucide icons, custom CSS (light/dark, responsive, print styles)
- **Backend:** Python 3.12, FastAPI, SQLAlchemy 2, Pydantic v2, PyJWT, pypdf
- **Database:** SQLite for local dev, PostgreSQL (Supabase / Neon / Docker) for production
- **AI:** Anthropic Claude API (vision for photos, JSON extraction, explanation, chat). Optional: swap `llm.py` for Ollama/Llama.

## Run locally

### Option A: manual (recommended for development)

**Backend** (terminal 1)
```bash
cd backend
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # optionally add ANTHROPIC_API_KEY
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs

**Frontend** (terminal 2)
```bash
cd frontend
npm install
npm run dev
```
Open http://localhost:5173, create an account, then on **Reports** click **Use sample report**.

### Option B: Docker
```bash
export ANTHROPIC_API_KEY=sk-ant-...   # optional
docker compose up --build
```

## Try the demo in 2 minutes

1. Register and open **Reports** -> *Use sample report* -> **Analyse report**.
2. Also upload `sample_data/sample_lab_report_earlier.txt` (set an earlier date) to create trends.
3. Check **Dashboard** (Vita Score, pattern insights) and **Lab Trends**.
4. Add medicines `Warfarin` and `Aspirin` to see an interaction warning.
5. Ask the **Copilot**: "Which of my results need attention?" then type "I have chest pain" to see the safety layer.
6. Generate a **Doctor Visit Prep** brief and print it.

## Deploy publicly (free tiers)

1. **Database:** create a free project on Supabase or Neon, copy the Postgres connection string.
2. **Backend (Render):** push the repo to GitHub -> Render -> *New Blueprint* (uses `render.yaml`).
   Set `DATABASE_URL`, `CORS_ORIGINS` (your frontend URL) and optionally `ANTHROPIC_API_KEY`.
3. **Frontend (Vercel):** import the repo, set **Root Directory** to `frontend`, add env var
   `VITE_API_URL=https://<your-render-service>.onrender.com`, deploy.
4. Update `CORS_ORIGINS` on Render with the final Vercel URL and redeploy the backend.
5. Open `/api/health` on the backend: it should return `{"status":"ok"}`.

## Configuration

| Variable | Where | Purpose |
|---|---|---|
| `SECRET_KEY` | backend | Signs login tokens. Use a long random value in production |
| `DATABASE_URL` | backend | SQLite by default; use Postgres in production |
| `ANTHROPIC_API_KEY` | backend | Enables Claude. Blank = demo mode |
| `CLAUDE_MODEL` | backend | Model name (default `claude-sonnet-5-5`) |
| `CORS_ORIGINS` | backend | Comma-separated allowed frontend URLs |
| `VITE_API_URL` | frontend | Backend URL in production |

## Responsible AI and limitations

- VitaPilot gives **general health information, not diagnosis or treatment**.
- Reference ranges and the interaction list are an educational subset. Labs print their own ranges, which are used when parsed.
- Photos need an AI key (OCR via Claude vision). PDFs must contain selectable text.
- Before real users: add rate limiting, HTTPS-only cookies/storage review, audit logging, encryption at rest and a clinician review of the knowledge base. This is a hackathon prototype.

## Roadmap

Wearable sync (Google Fit / Apple Health), WhatsApp reminders, ABHA / ABDM integration, DICOM/imaging reports, doctor sharing links with expiry, fine-tuned Indian-context health model.

## Project structure

```
vitapilot/
  backend/app/         FastAPI app: models, routers, llm.py (VitaMind), rag.py, safety.py, reference.py, knowledge/*.md
  frontend/src/        React app: pages, components, store, api client
  docs/                Architecture + pitch
  sample_data/         Sample lab reports for demos
  docker-compose.yml   Local full stack
  render.yaml          Backend deploy blueprint
```

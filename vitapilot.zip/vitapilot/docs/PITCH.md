# 3-minute pitch script

**Hook (20s):** "In India, a typical family has health records scattered across WhatsApp photos, paper files and email. When a doctor asks 'what were your last sugar levels?', nobody knows."

**Problem (20s):** Reports are written for doctors, not patients. People miss trends, forget medicines and walk into appointments unprepared.

**Solution (20s):** VitaPilot: one private place to understand, organise and manage your health, powered by VitaMind.

**Live demo (90s):**
1. Upload the sample report -> instant plain-language explanation (switch to Hindi).
2. Dashboard: Vita Score and Pattern Detector.
3. Trends chart across two reports.
4. Add Warfarin + Aspirin -> interaction warning.
5. Copilot: grounded answer with sources, then "chest pain" -> safety layer.
6. Visit Prep -> print a one-page brief.

**Why we are different (20s):** Safety before AI, grounded answers with sources, multilingual, family profiles, privacy controls (export / delete), runs even without an API key.

**Impact and next steps (10s):** ABHA integration, WhatsApp reminders, wearables.

## Likely judge questions
- *Hallucination?* Answers are retrieval-grounded, cite sources, and the prompt forbids inventing values.
- *Privacy?* Ownership checks on every query, hashed passwords, export + delete, no data sold or shared.
- *Medical liability?* Never diagnoses; emergency intercept; clear disclaimers.
- *Scalability?* Stateless FastAPI + Postgres; swap BM25 for pgvector embeddings.

# Architecture

## Request flow for a chat question
1. React sends `POST /api/profiles/{id}/chat` with the JWT.
2. `owned_profile()` verifies the profile belongs to the logged-in user.
3. **Safety layer** (`safety.py`) scans the text. Emergency or self-harm phrases return a fixed, vetted reply with Indian helplines and the AI is *not* called.
4. **Retrieval** (`rag.py`): the person's own labs, medicines, profile and report text are turned into chunks and merged with `knowledge/*.md`. A BM25 ranker picks the top 6 (user data is boosted x1.4).
5. **VitaMind** (`llm.py`) sends the chunks plus a strict system prompt to Claude. If no key exists, demo mode composes an answer from the same chunks.
6. The answer and its source labels are stored and returned.

## Report ingestion
`upload -> text extraction (pypdf / Claude vision / plain text) -> structured lab extraction (Claude JSON, regex fallback) -> normalise names -> classify vs reference range -> store -> AI explanation`.

## Data model
User 1-N Profile 1-N {Report 1-N LabResult, Medicine 1-N DoseLog, ChatMessage}. Deleting a user or profile cascades to all health data.

## Security
- PBKDF2-SHA256 (200k iterations) password hashing, signed JWT with expiry
- Every route resolves ownership through `owned_profile` / `owned_report` / `owned_med`
- Upload size limit, security headers, CORS allow-list
- Data export and permanent deletion endpoints

## Why not train an LLM from scratch?
Training needs millions of dollars of compute. VitaMind instead specialises a frontier model through grounding (RAG), policy (safety layer + system prompt) and structure (schema-constrained extraction). This is how production health assistants are built and it can be swapped to an open-source model by editing `VitaMind._call`.
